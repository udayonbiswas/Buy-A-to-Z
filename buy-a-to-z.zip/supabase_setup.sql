-- 🚀 COMPLETE DATABASE SETUP & RECOVERY (v14 - FINAL STABLE)
-- RUN THIS IN SUPABASE SQL EDITOR TO FIX ALL TABLES & RLS ERRORS

-- 1. ALL TABLES SETUP
CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, name TEXT NOT NULL, price NUMERIC NOT NULL, "originalPrice" NUMERIC, image TEXT, category TEXT, rating NUMERIC DEFAULT 4.5, "reviewCount" INTEGER DEFAULT 0, discount NUMERIC DEFAULT 0, stock INTEGER DEFAULT 0, location TEXT, "partNumber" TEXT, "galleryImages" JSONB DEFAULT '[]'::jsonb, "availableSizes" JSONB DEFAULT '[]'::jsonb, "showSizes" BOOLEAN DEFAULT true, "availableColors" JSONB DEFAULT '[]'::jsonb, "showColors" BOOLEAN DEFAULT true, "freeDelivery" BOOLEAN DEFAULT false, "isReturnable" BOOLEAN DEFAULT true, "returnDays" INTEGER, video TEXT, description TEXT, weight TEXT, "showNewBadge" BOOLEAN DEFAULT false, "newBadgeText" TEXT, "vatPercentage" NUMERIC, "isVatEnabled" BOOLEAN DEFAULT true, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS categories (id TEXT PRIMARY KEY, name TEXT NOT NULL, icon TEXT, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS banners (id TEXT PRIMARY KEY, title TEXT, subtitle TEXT, "buttonText" TEXT, "imageUrl" TEXT, "backgroundColor" TEXT, "textColor" TEXT, "categoryLink" TEXT, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, "customerId" TEXT, "customerName" TEXT, "customerEmail" TEXT, "customerMobile" TEXT, items JSONB NOT NULL DEFAULT '[]'::jsonb, total NUMERIC NOT NULL, status TEXT DEFAULT 'processing', timestamp TIMESTAMPTZ DEFAULT NOW(), delivery JSONB NOT NULL DEFAULT '{}'::jsonb, payment JSONB NOT NULL DEFAULT '{}'::jsonb, "trackingNumber" TEXT, "trackingCarrier" TEXT, "couponCode" TEXT, "couponDiscount" NUMERIC, "vatAmount" NUMERIC, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS users (uid TEXT PRIMARY KEY, id TEXT, "fullName" TEXT, email TEXT UNIQUE, "mobileNumber" TEXT, password TEXT, avatar TEXT, role TEXT DEFAULT 'user', "isAdmin" BOOLEAN DEFAULT false, "isVerified" BOOLEAN DEFAULT false, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS configs (key TEXT PRIMARY KEY, value JSONB NOT NULL, updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS reviews (id TEXT PRIMARY KEY, "productId" TEXT, "userId" TEXT, "userName" TEXT, rating INTEGER, comment TEXT, timestamp TIMESTAMPTZ DEFAULT NOW(), images JSONB DEFAULT '[]'::jsonb, video TEXT);
CREATE TABLE IF NOT EXISTS suppliers (id TEXT PRIMARY KEY, name TEXT NOT NULL, "contactPerson" TEXT, phone TEXT, email TEXT, address TEXT, "category" TEXT, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS purchases (id TEXT PRIMARY KEY, "supplierId" TEXT, "supplierName" TEXT, timestamp TIMESTAMPTZ DEFAULT NOW(), items JSONB DEFAULT '[]'::jsonb, "totalAmount" NUMERIC, status TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS return_requests (id TEXT PRIMARY KEY, "orderId" TEXT NOT NULL, "customerId" TEXT, "customerName" TEXT, "customerEmail" TEXT, "customerMobile" TEXT, items JSONB NOT NULL DEFAULT '[]'::jsonb, reason TEXT NOT NULL, details TEXT, status TEXT DEFAULT 'requested', "adminNotes" TEXT, timestamp TIMESTAMPTZ DEFAULT NOW(), "updatedAtByAdmin" TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS product_videos (product_id TEXT PRIMARY KEY, video_data TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW());

-- 2. ENSURE ALL COLUMNS EXIST (FOR UPDATES)
ALTER TABLE products ADD COLUMN IF NOT EXISTS "availableSizes" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "showSizes" BOOLEAN DEFAULT true;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "availableColors" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "showColors" BOOLEAN DEFAULT true;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "galleryImages" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "description" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "partNumber" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "location" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "weight" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "originalPrice" NUMERIC;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "rating" NUMERIC DEFAULT 4.5;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "reviewCount" INTEGER DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "freeDelivery" BOOLEAN DEFAULT false;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "isReturnable" BOOLEAN DEFAULT true;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "returnDays" INTEGER;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "video" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "showNewBadge" BOOLEAN DEFAULT false;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "newBadgeText" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "vatPercentage" NUMERIC;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "isVatEnabled" BOOLEAN DEFAULT true;

-- Users
ALTER TABLE users ADD COLUMN IF NOT EXISTS id TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "mobileNumber" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "isVerified" BOOLEAN DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "referredBy" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "referredByUserId" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "address" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "nid" TEXT;

-- Orders
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "couponCode" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "couponDiscount" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "vatAmount" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "trackingNumber" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "trackingCarrier" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerId" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerName" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerEmail" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerMobile" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS items JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS total NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS status TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery JSONB DEFAULT '{}'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment JSONB DEFAULT '{}'::jsonb;

-- Suppliers schema alter checking
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "contactPerson" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "phone" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "email" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "address" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "category" TEXT;

-- Purchases schema alter checking
ALTER TABLE purchases ADD COLUMN IF NOT EXISTS "supplierId" TEXT;
ALTER TABLE purchases ADD COLUMN IF NOT EXISTS "supplierName" TEXT;
ALTER TABLE purchases ADD COLUMN IF NOT EXISTS "timestamp" TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE purchases ADD COLUMN IF NOT EXISTS "items" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE purchases ADD COLUMN IF NOT EXISTS "totalAmount" NUMERIC;
ALTER TABLE purchases ADD COLUMN IF NOT EXISTS "status" TEXT DEFAULT 'pending';
ALTER TABLE purchases ADD COLUMN IF NOT EXISTS "note" TEXT;

-- Return Request schema alter checking
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "orderId" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "customerId" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "customerName" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "customerEmail" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "customerMobile" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "items" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "reason" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "details" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "status" TEXT DEFAULT 'requested';
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "adminNotes" TEXT;
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "timestamp" TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE return_requests ADD COLUMN IF NOT EXISTS "updatedAtByAdmin" TIMESTAMPTZ DEFAULT NOW();

-- Remove problematic unique constraint on mobileNumber if it exists
DO $$ 
BEGIN 
  IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'users_mobileNumber_key') THEN
    ALTER TABLE users DROP CONSTRAINT "users_mobileNumber_key";
  END IF;
END $$;

-- 3. 🔓 DISABLE RLS & ALLOW PUBLIC ACCESS (FIXES ALL PIRACY/SECURITY ERRORS)
DO $$ 
BEGIN
  -- Products
  ALTER TABLE IF EXISTS products DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_p" ON products;
  CREATE POLICY "public_p" ON products FOR ALL USING (true) WITH CHECK (true);
  
  -- Suppliers
  ALTER TABLE IF EXISTS suppliers DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_s" ON suppliers;
  CREATE POLICY "public_s" ON suppliers FOR ALL USING (true) WITH CHECK (true);

  -- Purchases
  ALTER TABLE IF EXISTS purchases DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_pur" ON purchases;
  CREATE POLICY "public_pur" ON purchases FOR ALL USING (true) WITH CHECK (true);
  
  -- Categories
  ALTER TABLE IF EXISTS categories DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_c" ON categories;
  CREATE POLICY "public_c" ON categories FOR ALL USING (true) WITH CHECK (true);

  -- Orders
  ALTER TABLE IF EXISTS orders DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_o" ON orders;
  CREATE POLICY "public_o" ON orders FOR ALL USING (true) WITH CHECK (true);

  -- Users
  ALTER TABLE IF EXISTS users DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_u" ON users;
  CREATE POLICY "public_u" ON users FOR ALL USING (true) WITH CHECK (true);

  -- Banners
  ALTER TABLE IF EXISTS banners DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_b" ON banners;
  CREATE POLICY "public_b" ON banners FOR ALL USING (true) WITH CHECK (true);

  -- Configs
  ALTER TABLE IF EXISTS configs DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_cfg" ON configs;
  CREATE POLICY "public_cfg" ON configs FOR ALL USING (true) WITH CHECK (true);

  -- Reviews
  ALTER TABLE IF EXISTS reviews DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_r" ON reviews;
  CREATE POLICY "public_r" ON reviews FOR ALL USING (true) WITH CHECK (true);

  -- Return Requests
  ALTER TABLE IF EXISTS return_requests DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_ret" ON return_requests;
  CREATE POLICY "public_ret" ON return_requests FOR ALL USING (true) WITH CHECK (true);

  -- Product Videos
  ALTER TABLE IF EXISTS product_videos DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_pv" ON product_videos;
  CREATE POLICY "public_pv" ON product_videos FOR ALL USING (true) WITH CHECK (true);
END $$;

-- 🔄 RELOAD POSTGREST SCHEMA CACHE (Clears any "Could not find column in schema cache" errors)
NOTIFY pgrst, 'reload schema';

-- 4. 🔗 DEDICATED AFFILIATE TABLES SETUP & RLS BYPASS
-- COPY AND RUN THIS ENTIRE SECTION IN THE SUPABASE SQL EDITOR TO CREATE THE NEW TABLES

CREATE TABLE IF NOT EXISTS affiliate_profiles (
  uid TEXT PRIMARY KEY,
  "fullName" TEXT,
  "mobileNumber" TEXT,
  email TEXT,
  address TEXT,
  nid TEXT,
  "affiliateCode" TEXT,
  "affiliateStatus" TEXT,
  "affiliateBalance" NUMERIC DEFAULT 0,
  "affiliateBonusBalance" NUMERIC DEFAULT 0,
  "totalEarned" NUMERIC DEFAULT 0,
  "isAffiliate" BOOLEAN DEFAULT true,
  "referredBy" TEXT,
  "appliedAt" TIMESTAMPTZ,
  "approvedAt" TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure affiliateBonusBalance column exists in case the table already existed
ALTER TABLE affiliate_profiles ADD COLUMN IF NOT EXISTS "affiliateBonusBalance" NUMERIC DEFAULT 0;
ALTER TABLE affiliate_profiles ADD COLUMN IF NOT EXISTS "referredByUserId" TEXT;
ALTER TABLE affiliate_profiles ADD COLUMN IF NOT EXISTS "userId" TEXT;
ALTER TABLE affiliate_profiles ADD COLUMN IF NOT EXISTS "introText" TEXT;

CREATE TABLE IF NOT EXISTS affiliate_withdrawals (
  id TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "userFullName" TEXT,
  "userMobile" TEXT,
  amount NUMERIC NOT NULL,
  method TEXT,
  "paymentDetails" TEXT,
  status TEXT DEFAULT 'pending',
  timestamp TIMESTAMPTZ,
  "adminNotes" TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS affiliate_transactions (
  id TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  type TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  status TEXT DEFAULT 'pending',
  description TEXT,
  timestamp TIMESTAMPTZ,
  "orderId" TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS affiliate_messages (
  id TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "userName" TEXT,
  "userMobile" TEXT,
  subject TEXT,
  message TEXT,
  reply TEXT,
  timestamp TIMESTAMPTZ,
  "repliedAt" TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- DISABLE RLS FOR NEW AFFILIATE TABLES & GRANT PUBLIC ACCESS
DO $$ 
BEGIN
  -- Profiles
  ALTER TABLE IF EXISTS affiliate_profiles DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_ap" ON affiliate_profiles;
  CREATE POLICY "public_ap" ON affiliate_profiles FOR ALL USING (true) WITH CHECK (true);

  -- Withdrawals
  ALTER TABLE IF EXISTS affiliate_withdrawals DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_aw" ON affiliate_withdrawals;
  CREATE POLICY "public_aw" ON affiliate_withdrawals FOR ALL USING (true) WITH CHECK (true);

  -- Transactions
  ALTER TABLE IF EXISTS affiliate_transactions DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_at" ON affiliate_transactions;
  CREATE POLICY "public_at" ON affiliate_transactions FOR ALL USING (true) WITH CHECK (true);

  -- Messages
  ALTER TABLE IF EXISTS affiliate_messages DISABLE ROW LEVEL SECURITY;
  DROP POLICY IF EXISTS "public_am" ON affiliate_messages;
  CREATE POLICY "public_am" ON affiliate_messages FOR ALL USING (true) WITH CHECK (true);
END $$;

NOTIFY pgrst, 'reload schema';

-- 🔐 Alternatively, if you want RLS, run these policies:
-- DROP POLICY IF EXISTS "public_access" ON products;
-- CREATE POLICY "public_access" ON products FOR ALL USING (true) WITH CHECK (true);
