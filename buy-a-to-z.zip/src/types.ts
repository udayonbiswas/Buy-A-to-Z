export interface Category {
  id: string;
  name: string;
  icon: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  rating: number;
  reviewCount: number;
  discount?: number;
  stock: number;
  location?: string;
  partNumber?: string;
  galleryImages?: string[];
  video?: string;
  description?: string;
  availableSizes?: string[];
  showSizes?: boolean;
  availableColors?: string[];
  showColors?: boolean;
  freeDelivery?: boolean;
  isReturnable?: boolean;
  returnDays?: number;
  showNewBadge?: boolean;
  newBadgeText?: string;
  vatPercentage?: number;
  isVatEnabled?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface User {
  uid: string;
  fullName: string;
  mobileNumber: string;
  email: string;
  password?: string;
  avatar?: string;
  role?: 'admin' | 'user';
  isAdmin?: boolean;
  isVerified?: boolean;
  isAffiliate?: boolean;
  affiliateCode?: string;
  referredBy?: string;
  affiliateBalance?: number;
  affiliateBonusBalance?: number;
  affiliateStatus?: 'pending' | 'approved' | 'rejected';
  affiliateJoinDate?: any;
  address?: string;
  nid?: string;
}

export interface AffiliateWithdrawal {
  id: string;
  userId: string;
  userFullName: string;
  userMobile: string;
  amount: number;
  method: 'bkash' | 'nagad' | 'rocket' | 'bank';
  paymentDetails: string;
  status: 'pending' | 'approved' | 'rejected';
  timestamp: any;
  adminNotes?: string;
}

export interface AffiliateTransaction {
  id: string;
  userId: string;
  type: 'earning' | 'withdraw' | 'bonus' | 'purchase';
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  description: string;
  timestamp: any;
  orderId?: string;
}

export interface AffiliateMessage {
  id: string;
  userId: string;
  userName: string;
  userMobile: string;
  subject: string;
  message: string;
  reply?: string;
  timestamp: any;
  repliedAt?: any;
}

export interface AffiliateConfig {
  isEnabled: boolean;
  referralRewardAmount: number;
  commissionPercentage: number;
  minimumWithdrawal: number;
}


export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerMobile: string;
  items: CartItem[];
  total: number;
  status: 'processing' | 'shipped' | 'delivered' | 'cancelled';
  timestamp: any;
  delivery: {
    address: string;
    city: string;
    area: string;
    deliveryType: 'standard' | 'express' | 'free';
    notes?: string;
    charge?: number;
  };
  payment: {
    method: string;
    paymentStatus?: string;
    trxId?: string;
    senderMobile?: string;
    receiverNumber?: string;
  };
  trackingNumber?: string;
  trackingCarrier?: string;
  couponCode?: string;
  couponDiscount?: number;
  vatAmount?: number;
  bonusBalanceApplied?: number;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  timestamp: any;
  images?: string[];
  video?: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  buttonText: string;
  imageUrl?: string; // Optional if we use gradient instead
  backgroundColor?: string;
  textColor?: string;
  categoryLink?: string;
}

export interface FooterConfig {
  companyName: string;
  logoUrl?: string;
  showName?: boolean;
  copyrightText: string;
  homeLabel?: string;
  customerCareText: string;
  customerCarePhone: string;
  sellOnText: string;
  appDownloadText: string;
  appDownloadLink: string;
  showSecuredBy: boolean;
  showAppDownload?: boolean;
  paymentMethods?: string[];
  facebookUrl?: string;
  instagramUrl?: string;
  twitterUrl?: string;
  youtubeUrl?: string;
  helpCenterUrl?: string;
  howToBuyUrl?: string;
  returnsRefundsUrl?: string;
  contactUsUrl?: string;
  aboutUsUrl?: string;
  digitalPaymentsUrl?: string;
  flashSaleUrl?: string;
  termsConditionsUrl?: string;
  privacyPolicyUrl?: string;
  termsOfUseUrl?: string;
  companyAddress?: string;
  companyPhone?: string;
  companyEmail?: string;
  companyTin?: string;
  companyTradeLic?: string;
  showCompanyAddress?: boolean;
  showCompanyPhone?: boolean;
  showCompanyEmail?: boolean;
  showCompanyTin?: boolean;
  showCompanyTradeLic?: boolean;
}

export interface PromotionConfig {
  title: string;
  description: string;
  discountAmount: number;
  isActive: boolean;
  promoCodeEnabled?: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  email?: string;
  address?: string;
}

export interface Purchase {
  id: string;
  supplierId: string;
  supplierName: string;
  timestamp: any;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    costPrice: number;
  }[];
  totalAmount: number;
  status: 'completed' | 'pending';
  note?: string;
}

export interface ReturnRequestItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
  selectedSize?: string;
  selectedColor?: string;
  image?: string;
}

export interface ReturnRequest {
  id: string;
  orderId: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerMobile: string;
  items: ReturnRequestItem[];
  reason: string;
  details?: string;
  status: 'requested' | 'approved' | 'pickup' | 'quality_check' | 'refunded' | 'rejected';
  adminNotes?: string;
  timestamp: any;
  updatedAtByAdmin?: any;
}

export interface ReturnConfig {
  days: number;
  isEnabled: boolean;
  stages: { key: string; labelBn: string; labelEn: string; color: string }[];
  reasons?: string[];
}

export interface MerchantPaymentAccountConfig {
  bkashNumber: string;
  bkashType: 'personal' | 'merchant' | 'agent';
  bkashEnabled: boolean;
  bkashInstructions?: string;
  bkashQrCodeUrl?: string;
  nagadNumber: string;
  nagadType: 'personal' | 'merchant';
  nagadEnabled: boolean;
  nagadInstructions?: string;
  nagadQrCodeUrl?: string;
  rocketNumber: string;
  rocketType: 'personal' | 'merchant';
  rocketEnabled: boolean;
  rocketInstructions?: string;
  rocketQrCodeUrl?: string;
  bankName: string;
  bankAccountNo: string;
  bankAccountHolder: string;
  bankBranch: string;
  bankEnabled: boolean;
  codEnabled: boolean;
  instructions: string;
  standardShippingFee?: number;
  expressShippingFee?: number;
  standardDeliveryEnabled?: boolean;
  expressDeliveryEnabled?: boolean;
  standardDeliveryTitle?: string;
  standardDeliveryDays?: string;
  expressDeliveryTitle?: string;
  expressDeliveryDays?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'flat' | 'percentage';
  discountValue: number;
  minPurchaseAmount: number;
  isActive: boolean;
  description?: string;
  expiryDate?: string;
}


