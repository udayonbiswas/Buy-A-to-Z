import React, { useState } from "react";
import {
  Users,
  CheckCircle2,
  XCircle,
  Wallet,
  Settings,
  MessageSquare,
  Search,
  Check,
  X,
  Send,
  HelpCircle,
  Edit2,
  DollarSign,
  UserCheck,
  AlertCircle,
  TrendingUp,
  Award,
  ArrowRightLeft,
  Trash2
} from "lucide-react";
import {
  AffiliateConfig,
  AffiliateWithdrawal,
  AffiliateTransaction,
  AffiliateMessage,
  User as UserType
} from "../types";
import { supabase } from "../lib/supabase";

interface AdminAffiliatePanelProps {
  users: UserType[];
  affiliateConfig: AffiliateConfig;
  affiliateProfiles: Record<string, any>;
  affiliateWithdrawals: AffiliateWithdrawal[];
  affiliateTransactions: AffiliateTransaction[];
  affiliateMessages: AffiliateMessage[];
  updateAffiliateConfig: (config: AffiliateConfig) => Promise<void>;
  updateAffiliateProfiles: (profiles: Record<string, any>) => Promise<void>;
  updateAffiliateWithdrawals: (withdrawals: AffiliateWithdrawal[]) => Promise<void>;
  updateAffiliateTransactions: (transactions: AffiliateTransaction[]) => Promise<void>;
  updateAffiliateMessages: (messages: AffiliateMessage[]) => Promise<void>;
}

export const AdminAffiliatePanel: React.FC<AdminAffiliatePanelProps> = ({
  users,
  affiliateConfig,
  affiliateProfiles,
  affiliateWithdrawals,
  affiliateTransactions,
  affiliateMessages,
  updateAffiliateConfig,
  updateAffiliateProfiles,
  updateAffiliateWithdrawals,
  updateAffiliateTransactions,
  updateAffiliateMessages
}) => {
  const [activeTab, setActiveTab] = useState<"config" | "applicants" | "withdrawals" | "support" | "all">("applicants");

  // Local States for Config tab
  const [configEnabled, setConfigEnabled] = useState(affiliateConfig?.isEnabled ?? true);
  const [configReferral, setConfigReferral] = useState(affiliateConfig?.referralRewardAmount ?? 100);
  const [configCommission, setConfigCommission] = useState(affiliateConfig?.commissionPercentage ?? 5);
  const [configMinWithdrawal, setConfigMinWithdrawal] = useState(affiliateConfig?.minimumWithdrawal ?? 500);

  // search/filter inputs
  const [searchQuery, setSearchQuery] = useState("");
  const [withdrawalFilter, setWithdrawalFilter] = useState<"all" | "pending" | "approved" | "rejected">("all");

  // Form entries
  const [adminNotesText, setAdminNotesText] = useState<Record<string, string>>({});
  const [replyTextMap, setReplyTextMap] = useState<Record<string, string>>({});

  // Editing profile state
  const [editingUid, setEditingUid] = useState<string | null>(null);
  const [editBalance, setEditBalance] = useState<number>(0);
  const [editBonusBalance, setEditBonusBalance] = useState<number>(0);
  const [editCode, setEditCode] = useState<string>("");
  const [editStatus, setEditStatus] = useState<"pending" | "approved" | "rejected">("approved");

  // Deletion and safe notification states
  const [deletingUid, setDeletingUid] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);

  const showToast = (message: string, type: "success" | "error" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Save Config function
  const handleSaveConfig = async () => {
    try {
      const updatedConfig: AffiliateConfig = {
        isEnabled: configEnabled,
        referralRewardAmount: Number(configReferral),
        commissionPercentage: Number(configCommission),
        minimumWithdrawal: Number(configMinWithdrawal)
      };
      await updateAffiliateConfig(updatedConfig);
      alert("✅ এফিলিয়েট কনফিগারেশন সফলভাবে আপডেট করা হয়েছে!");
    } catch (err: any) {
      alert("❌ কনফিগারেশন সেভ করতে সমস্যা হয়েছে: " + err.message);
    }
  };

  // Profile actions
  const handleApproveApplicant = async (uid: string) => {
    const current = affiliateProfiles[uid];
    if (!current) return;
    const updatedProfiles = {
      ...affiliateProfiles,
      [uid]: {
        ...current,
        affiliateStatus: "approved" as const,
        approvedAt: new Date().toISOString()
      }
    };
    await updateAffiliateProfiles(updatedProfiles);
    alert("✅ আবেদনটি সফলভাবে অনুমোদন করা হয়েছে!");
  };

  const handleRejectApplicant = async (uid: string) => {
    const current = affiliateProfiles[uid];
    if (!current) return;
    const updatedProfiles = {
      ...affiliateProfiles,
      [uid]: {
        ...current,
        affiliateStatus: "rejected" as const,
        rejectedAt: new Date().toISOString()
      }
    };
    await updateAffiliateProfiles(updatedProfiles);
    alert("❌ আবেদনটি বাতিল করা হয়েছে।");
  };

  // Withdrawal actions
  const handleApproveWd = async (withdrawId: string) => {
    const note = adminNotesText[withdrawId] || "";
    if (!note.trim()) {
      alert("প্লিজ টাকা পাঠানোর ট্রানজেকশন আইডি বা নোট লিখুন।");
      return;
    }

    try {
      // 1. Update withdrawal list
      const updatedWds = affiliateWithdrawals.map(wd => {
        if (wd.id === withdrawId) {
          return { ...wd, status: "approved" as const, adminNotes: note.trim(), approvedAt: new Date().toISOString() };
        }
        return wd;
      });
      await updateAffiliateWithdrawals(updatedWds);

      // 2. Update transaction status
      const currentWd = affiliateWithdrawals.find(wd => wd.id === withdrawId);
      if (currentWd) {
        const updatedTxs = affiliateTransactions.map(tx => {
          if (tx.userId === currentWd.userId && tx.type === "withdraw" && tx.description.includes(withdrawId)) {
            return { ...tx, status: "completed" as const };
          }
          return tx;
        });
        await updateAffiliateTransactions(updatedTxs);
      }

      setAdminNotesText(prev => {
        const next = { ...prev };
        delete next[withdrawId];
        return next;
      });

      alert("✅ ওয়ালেট ক্যাশআউট সফলভাবে পেমেন্ট অনুমোদন করা হয়েছে!");
    } catch (err: any) {
      alert("❌ প্রসেস করতে ত্রুটি হয়েছে: " + err.message);
    }
  };

  const handleRejectWd = async (withdrawId: string) => {
    const note = adminNotesText[withdrawId] || "";
    if (!note.trim()) {
      alert("প্লিজ টাকা বাতিল করার কারণ বা বিবরণ নোট হিসেবে লিখুন।");
      return;
    }

    try {
      const currentWd = affiliateWithdrawals.find(wd => wd.id === withdrawId);
      if (!currentWd) return;

      // 1. Update withdrawal status to 'rejected'
      const updatedWds = affiliateWithdrawals.map(wd => {
        if (wd.id === withdrawId) {
          return { ...wd, status: "rejected" as const, adminNotes: note.trim() };
        }
        return wd;
      });
      await updateAffiliateWithdrawals(updatedWds);

      // 2. Refund original balance to user's profiles
      const uid = currentWd.userId;
      const profile = affiliateProfiles[uid];
      if (profile) {
        const updatedProfiles = {
          ...affiliateProfiles,
          [uid]: {
            ...profile,
            affiliateBalance: (profile.affiliateBalance || 0) + currentWd.amount
          }
        };
        await updateAffiliateProfiles(updatedProfiles);
      }

      // 3. Set transaction status to 'failed'
      const updatedTxs = affiliateTransactions.map(tx => {
        if (tx.userId === currentWd.userId && tx.type === "withdraw" && tx.description.includes(withdrawId)) {
          return { ...tx, status: "failed" as const, description: tx.description + " (বাতিল ও রিফান্ডকৃত)" };
        }
        return tx;
      });
      await updateAffiliateTransactions(updatedTxs);

      setAdminNotesText(prev => {
        const next = { ...prev };
        delete next[withdrawId];
        return next;
      });

      alert("❌ ক্যাশআউট পেমেন্টটি বাতিল এবং কাস্টমারের ওয়ালেটে রিফান্ড করা হয়েছে।");
    } catch (err: any) {
      alert("❌ প্রসেস করতে ত্রুটি হয়েছে: " + err.message);
    }
  };

  // Support messages reply
  const handleSendReply = async (msgId: string) => {
    const text = replyTextMap[msgId] || "";
    if (!text.trim()) {
      alert("প্লিজ রিপ্লাইয়ের টেক্সট লিখুন।");
      return;
    }

    try {
      const updatedMsgs = affiliateMessages.map(msg => {
        if (msg.id === msgId) {
          return { ...msg, reply: text.trim(), repliedAt: new Date().toISOString() };
        }
        return msg;
      });
      await updateAffiliateMessages(updatedMsgs);

      setReplyTextMap(prev => {
        const next = { ...prev };
        delete next[msgId];
        return next;
      });

      alert("✅ আপনার উত্তর সফলভাবে পাঠানো হয়েছে!");
    } catch (err: any) {
      alert("❌ রিপ্লাই করতে ত্রুটি হয়েছে: " + err.message);
    }
  };

  // Manual Profile adjustment
  const handleStartEditProfile = (uid: string, prof: any) => {
    setEditingUid(uid);
    setEditBalance(prof.affiliateBalance || 0);
    setEditBonusBalance(prof.affiliateBonusBalance || 0);
    setEditCode(prof.affiliateCode || "");
    setEditStatus(prof.affiliateStatus || "approved");
  };

  const handleSaveProfileEdit = async (uid: string) => {
    const trimmedCode = editCode.trim().toUpperCase();
    if (!trimmedCode) {
      alert("কোডটি শূন্য হতে পারবে না।");
      return;
    }

    const duplicate = Object.values(affiliateProfiles).find(
      (p: any) => p && p.uid !== uid && p.affiliateCode?.toLowerCase() === trimmedCode.toLowerCase() && p.affiliateStatus !== "deleted"
    );
    if (duplicate) {
      alert("এই কোডটি ইতিমধ্যে অন্য কোনো প্রোফাইলে ব্যবহার করা হচ্ছে!");
      return;
    }

    try {
      const current = affiliateProfiles[uid];
      const updatedProfiles = {
        ...affiliateProfiles,
        [uid]: {
          ...current,
          affiliateBalance: Number(editBalance),
          affiliateBonusBalance: Number(editBonusBalance),
          affiliateCode: trimmedCode,
          affiliateStatus: editStatus
        }
      };
      await updateAffiliateProfiles(updatedProfiles);
      setEditingUid(null);
      alert("✅ প্রোফাইল সফলভাবে আপডেট করা হয়েছে!");
    } catch (err: any) {
      alert("❌ আপডেট করতে সমস্যা হয়েছে: " + err.message);
    }
  };

  const handleDeleteProfile = (uid: string) => {
    setDeletingUid(uid);
  };

  const executeDeleteProfile = async (uid: string) => {
    try {
      // 1. Completely delete from Supabase affiliate_profiles table
      const { error: dbErr } = await supabase
        .from("affiliate_profiles")
        .delete()
        .eq("uid", uid);
      if (dbErr) {
        console.warn("Failed to delete from affiliate_profiles table by uid:", dbErr.message);
      }

      await supabase
        .from("affiliate_profiles")
        .delete()
        .eq("userId", uid);

      // Explicitly add to deleted_affiliates config key in database to guarantee real-time sync
      try {
        const { data: cfgData } = await supabase
          .from("configs")
          .select("value")
          .eq("key", "deleted_affiliates")
          .maybeSingle();
        
        let currentDeleted: string[] = [];
        if (cfgData?.value && Array.isArray(cfgData.value)) {
          currentDeleted = cfgData.value;
        }
        
        if (!currentDeleted.includes(uid)) {
          const updatedDeleted = [...currentDeleted, uid];
          await supabase
            .from("configs")
            .upsert({ key: "deleted_affiliates", value: updatedDeleted }, { onConflict: "key" });
        }
      } catch (err) {
        console.warn("Failed to sync deleted_affiliates to cloud:", err);
      }

      // 2. Set status to 'deleted' in local state configs
      const updatedProfiles = { ...affiliateProfiles };
      let foundAny = false;
      Object.keys(updatedProfiles).forEach(key => {
        if (key === uid || updatedProfiles[key]?.uid === uid || updatedProfiles[key]?.userId === uid) {
          updatedProfiles[key] = {
            ...updatedProfiles[key],
            affiliateStatus: "deleted"
          };
          foundAny = true;
        }
      });
      if (!foundAny) {
        updatedProfiles[uid] = {
          uid,
          affiliateStatus: "deleted"
        };
      }

      // Pass the explicitly deleted UID as the second argument
      await (updateAffiliateProfiles as any)(updatedProfiles, uid);
      showToast("✅ এফিলিয়েট প্রোফাইলটি সফলভাবে মুছে ফেলা হয়েছে!", "success");
    } catch (err: any) {
      showToast("❌ মুছে ফেলতে সমস্যা হয়েছে: " + err.message, "error");
    }
  };

  // Filter lists based on tab & searchQuery
  const profileList = Object.entries(affiliateProfiles || {})
    .map(([key, val]: [string, any]) => {
      const safeVal = (val && typeof val === "object") ? val : {};
      return {
        ...safeVal,
        uid: safeVal.uid || safeVal.userId || key,
        userId: safeVal.userId || safeVal.uid || key
      };
    })
    .filter((p: any) => p.affiliateStatus !== "deleted");
  
  const pendingApplicants = profileList.filter((p: any) => p.affiliateStatus === "pending");

  const filteredAllProfiles = profileList.filter((p: any) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      p.fullName?.toLowerCase().includes(query) ||
      p.email?.toLowerCase().includes(query) ||
      p.mobileNumber?.includes(query) ||
      p.affiliateCode?.toLowerCase().includes(query)
    );
  });

  const filteredWithdrawals = affiliateWithdrawals.filter(wd => {
    if (withdrawalFilter !== "all" && wd.status !== withdrawalFilter) return false;
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      wd.userFullName?.toLowerCase().includes(query) ||
      wd.paymentDetails?.includes(query) ||
      wd.method?.toLowerCase().includes(query)
    );
  });

  return (
    <div className="flex flex-col min-h-0 h-full bg-slate-50">
      {/* Upper Navigation Tabs */}
      <div className="bg-white border-b px-6 py-3 flex flex-wrap gap-2 items-center justify-between shadow-sm shrink-0">
        <div className="flex gap-1.5 overflow-x-auto">
          {[
            { id: "applicants", label: `Applicants (${pendingApplicants.length})`, icon: Users },
            { id: "all", label: "All Affiliates", icon: UserCheck },
            { id: "withdrawals", label: "Withdrawals", icon: Wallet },
            { id: "support", label: "Support & Inbox", icon: MessageSquare },
            { id: "config", label: "Affiliate Setup", icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSel = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setSearchQuery("");
                }}
                className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all uppercase tracking-wider cursor-pointer ${
                  isSel
                    ? "bg-slate-900 text-white shadow-md shadow-slate-900/10"
                    : "text-slate-500 hover:bg-slate-100"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Global search inside list views */}
        {(activeTab === "all" || activeTab === "withdrawals") && (
          <div className="relative w-full sm:w-64 mt-2 sm:mt-0">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              placeholder="Search by name, email, code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 border-none rounded-xl pl-9 pr-4 py-2 text-xs outline-none focus:bg-white focus:ring-2 focus:ring-slate-900 transition-all font-medium"
            />
          </div>
        )}
      </div>

      {/* Main Content Pane */}
      <div className="flex-1 overflow-y-auto p-6">
        
        {/* 1. CONFIGURATION TAB */}
        {activeTab === "config" && (
          <div className="max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-sm p-6 space-y-6">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest border-b pb-3 flex items-center gap-2">
              <Settings className="w-5 h-5 text-indigo-600" /> System Global Affiliate Variables
            </h3>

            {/* Toggle Enable State */}
            <div className="flex items-center justify-between p-4 bg-indigo-50/50 rounded-xl border border-indigo-100">
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-wide">
                  Enable Affiliate Program / এফিলিয়েট প্রোগ্রাম চালু করুন
                </h4>
                <p className="text-[10px] text-gray-500 font-medium">
                  গ্রাহক বা কাস্টমার এফিলিয়েট অপশন দেখতে পাবে কিনা তা কন্ট্রোল করুন।
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={configEnabled}
                  onChange={(e) => setConfigEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-[10px] font-black text-slate-600 uppercase tracking-wider mb-2">
                  Commission Percentage (%)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={configCommission}
                    onChange={(e) => setConfigCommission(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold font-mono outline-none focus:border-indigo-500 focus:bg-white transition"
                  />
                  <span className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 font-black text-xs font-mono">%</span>
                </div>
                <p className="text-[9px] text-gray-400 mt-1 font-medium">প্রতিটি অর্ডারে পণ্যের মোট মূল্যের অর্জিত কমিশন হার।</p>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-600 uppercase tracking-wider mb-2">
                  Referral Reward (৳)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-gray-400 font-black text-xs font-mono">৳</span>
                  <input
                    type="number"
                    value={configReferral}
                    onChange={(e) => setConfigReferral(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 text-sm font-bold font-mono outline-none focus:border-indigo-500 focus:bg-white transition"
                  />
                </div>
                <p className="text-[9px] text-gray-400 mt-1 font-medium">যেকোনো রেফারেল সফলভাবে রেজিস্ট্রেশন করার পর বোনাস অ্যামাউন্ট।</p>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-600 uppercase tracking-wider mb-2">
                  Min Payout Target (৳)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-gray-400 font-black text-xs font-mono">৳</span>
                  <input
                    type="number"
                    value={configMinWithdrawal}
                    onChange={(e) => setConfigMinWithdrawal(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 text-sm font-bold font-mono outline-none focus:border-indigo-500 focus:bg-white transition"
                  />
                </div>
                <p className="text-[9px] text-gray-400 mt-1 font-medium">ওয়ালেট থেকে টাকা ক্যাশআউট করার সর্বনিম্ন সীমা।</p>
              </div>
            </div>

            <button
              onClick={handleSaveConfig}
              className="bg-indigo-650 hover:bg-indigo-700 bg-indigo-600 text-white font-extrabold text-xs uppercase px-6 py-3 rounded-xl transition shadow-md active:scale-95"
            >
              Update Global Settings
            </button>
          </div>
        )}

        {/* 2. APPLICANTS TAB */}
        {activeTab === "applicants" && (
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest border-b pb-3 mb-5 flex items-center gap-2">
              <Users className="w-5 h-5 text-orange-600" /> Pending Affiliate Applications / রেজিস্ট্রেশন আবেদন ({pendingApplicants.length})
            </h3>

            {pendingApplicants.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-gray-400 text-sm font-semibold">কোনো আবেদন অমীমাংসিত অবস্থায় নেই।</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {pendingApplicants.map((p: any) => (
                  <div key={p.uid} className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="text-sm font-bold text-slate-800 font-heading">{p.fullName}</h4>
                          <p className="text-xs text-slate-400 font-mono">{p.email}</p>
                        </div>
                        <span className="text-[9px] font-black uppercase bg-orange-100 text-orange-800 border border-orange-205 px-2 py-0.5 rounded-lg">
                          PENDING FOR APPROVAL
                        </span>
                      </div>

                      <div className="space-y-2.5 text-xs text-slate-600 border-t pt-3 mt-3">
                        <p><strong>Mobile / Payout contact:</strong> <span className="text-slate-900 font-bold">{p.mobileNumber}</span></p>
                        <p><strong>Verified Email Address:</strong> <span className="text-slate-900 font-bold font-mono">{p.email || "N/A"}</span></p>
                        <p><strong>Home Address:</strong> <span className="text-slate-800 font-medium">{p.address || "N/A"}</span></p>
                        {p.nid && <p><strong>NID Card Number:</strong> <span className="text-slate-900 font-mono font-bold">{p.nid}</span></p>}
                        {p.referredBy && <p><strong>Referred By Code:</strong> <span className="text-orange-700 bg-orange-50 px-1 py-0.5 rounded font-bold font-mono">{p.referredBy}</span></p>}
                        {p.introText && <p><strong>How they plan to promote:</strong> <span className="text-slate-500 block italic mt-1 bg-white p-2 border border-slate-100 rounded">"{p.introText}"</span></p>}
                        <p><strong>Preferred Custom Code:</strong> <span className="font-mono bg-white border px-1.5 py-0.5 text-indigo-700 font-black text-[12px] rounded">{p.affiliateCode}</span></p>
                        <p><strong>Applied Date:</strong> <span className="text-slate-500">{new Date(p.appliedAt).toLocaleString()}</span></p>
                      </div>
                    </div>

                    <div className="flex gap-2 border-t pt-4 mt-4">
                      <button
                        onClick={() => handleApproveApplicant(p.uid)}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 active:scale-[0.97]"
                      >
                        <CheckCircle2 className="w-4 h-4" /> Approve / অনুমোদন করুন
                      </button>
                      <button
                        onClick={() => handleRejectApplicant(p.uid)}
                        className="flex-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-xs uppercase py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 active:scale-[0.97]"
                      >
                        <XCircle className="w-4 h-4" /> Deny / বাতিল করুন
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 3. WITHDRAWALS TAB */}
        {activeTab === "withdrawals" && (
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 space-y-4">
            <div className="flex justify-between items-center border-b pb-3 mb-2 flex-wrap gap-3">
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
                <Wallet className="w-5 h-5 text-indigo-650" /> Payout Cache Withdrawal Requests / ওয়ালেট টাকা উত্তোলন
              </h3>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400">Filter Status:</span>
                <select
                  value={withdrawalFilter}
                  onChange={(e: any) => setWithdrawalFilter(e.target.value)}
                  className="bg-slate-100 border-none text-xs font-bold text-slate-700 px-3 py-1.5 rounded-xl outline-none"
                >
                  <option value="all">All Withdrawals</option>
                  <option value="pending">Pending</option>
                  <option value="approved">Approved</option>
                  <option value="rejected">Rejected</option>
                </select>
              </div>
            </div>

            {filteredWithdrawals.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-gray-400 text-sm font-semibold">কোনো টাকা উত্তোলনের হিস্টরি খুঁজে পাওয়া যায়নি।</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-medium border-collapse min-w-[700px]">
                  <thead>
                    <tr className="bg-slate-50 text-gray-400 uppercase text-[9px] tracking-wider border-b border-gray-100">
                      <th className="py-3 px-4">Applicant</th>
                      <th className="py-3 px-4">Amount</th>
                      <th className="py-3 px-4">Method</th>
                      <th className="py-3 px-4">Payment Account Details</th>
                      <th className="py-3 px-4">Date Submitted</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions / Trans ID</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredWithdrawals.map((wd) => (
                      <tr key={wd.id} className="hover:bg-slate-50/50">
                        <td className="py-3.5 px-4 font-bold text-slate-800">{wd.userFullName}</td>
                        <td className="py-3.5 px-4 font-black text-indigo-700 text-sm">৳{wd.amount}</td>
                        <td className="py-3.5 px-4">
                          <span className="bg-indigo-100 text-indigo-900 font-bold px-2.5 py-0.5 rounded text-[10px] uppercase font-mono">
                            {wd.method}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 font-bold font-mono">{wd.paymentDetails}</td>
                        <td className="py-3.5 px-4 text-gray-400">{new Date(wd.timestamp).toLocaleString()}</td>
                        <td className="py-3.5 px-4">
                          <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-full ${
                            wd.status === "approved" ? "bg-emerald-500 text-white" :
                            wd.status === "pending" ? "bg-amber-500 text-white" : "bg-rose-500 text-white"
                          }`}>
                            {wd.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          {wd.status === "pending" ? (
                            <div className="flex flex-col items-end gap-2">
                              <input
                                required
                                type="text"
                                placeholder="TxID / Transaction details *"
                                value={adminNotesText[wd.id] || ""}
                                onChange={(e) => setAdminNotesText(prev => ({ ...prev, [wd.id]: e.target.value }))}
                                className="border border-gray-200 outline-none focus:border-indigo-500 px-2 py-1 text-xs rounded-lg w-52 bg-white text-right font-medium"
                              />
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleApproveWd(wd.id)}
                                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black uppercase px-2.5 py-1.5 rounded-lg transition"
                                >
                                  Complete Payout
                                </button>
                                <button
                                  onClick={() => handleRejectWd(wd.id)}
                                  className="bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-[10px] font-black uppercase px-2.5 py-1.5 rounded-lg transition"
                                >
                                  Reject & Refund
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="text-right">
                              <span className="text-[10px] font-mono text-gray-400 block">Payout Notes:</span>
                              <span className="text-[11px] font-bold text-slate-700">{wd.adminNotes || "N/A"}</span>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* 4. SUPPORT MSGS INBOX */}
        {activeTab === "support" && (
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest border-b pb-3 mb-5 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-600" /> Affiliate Support Inquiries / সাপোর্ট বার্তা ({affiliateMessages.length})
            </h3>

            {affiliateMessages.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-gray-400 text-sm font-semibold">ইনবক্সে কোনো বার্তা নেই।</p>
              </div>
            ) : (
              <div className="space-y-6">
                {affiliateMessages.map((msg) => (
                  <div key={msg.id} className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4">
                    <div className="flex justify-between items-start border-b pb-2.5 flex-wrap gap-2">
                      <div>
                        <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">{msg.userName} ({msg.userMobile})</h4>
                        <p className="text-[10px] text-gray-400 mt-0.5">{new Date(msg.timestamp).toLocaleString()}</p>
                      </div>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                        msg.reply ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-rose-800"
                      }`}>
                        {msg.reply ? "REPLIED" : "NO REPLY"}
                      </span>
                    </div>

                    <div>
                      <p className="text-xs font-bold text-indigo-900 uppercase tracking-wide">Subject: {msg.subject}</p>
                      <p className="text-xs text-slate-700 mt-1 pb-2 leading-relaxed bg-white border border-slate-200/50 px-3.5 py-2.5 rounded-xl font-bold">
                        {msg.message}
                      </p>
                    </div>

                    {msg.reply ? (
                      <div className="bg-slate-100 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-600 space-y-1">
                        <strong className="text-slate-800 block text-[10px] uppercase font-black">Your Admin Reply:</strong>
                        <p className="font-medium text-slate-800">{msg.reply}</p>
                        <span className="text-[9px] text-slate-400 block mt-1">Replied At: {new Date(msg.repliedAt).toLocaleString()}</span>
                      </div>
                    ) : (
                      <div className="space-y-2 pt-2 border-t">
                        <textarea
                          placeholder="Type your admin reply here..."
                          value={replyTextMap[msg.id] || ""}
                          onChange={(e) => setReplyTextMap(prev => ({ ...prev, [msg.id]: e.target.value }))}
                          rows={2}
                          className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs outline-none focus:border-indigo-500 transition resize-none font-medium"
                        />
                        <button
                          onClick={() => handleSendReply(msg.id)}
                          className="bg-slate-900 hover:bg-slate-800 text-white font-black text-[10px] uppercase px-4 py-2 rounded-lg transition flex items-center gap-1 shadow-sm"
                        >
                          <Send className="w-3 h-3" /> Send Reply / উত্তর দিন
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 5. ALL AFFILIATES PROFILES */}
        {activeTab === "all" && (
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest border-b pb-3 mb-5 flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-600" /> All Registerd Affiliates / সকল এফিলিয়েট প্রোফাইল ({filteredAllProfiles.length})
            </h3>

            {filteredAllProfiles.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-gray-400 text-sm font-semibold">কোনো এফিলিয়েট একাউন্ট পাওয়া যায়নি।</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-medium border-collapse min-w-[800px]">
                  <thead>
                    <tr className="bg-slate-50 text-gray-400 uppercase text-[9px] tracking-wider border-b border-gray-100">
                      <th className="py-3 px-4">Full Name</th>
                      <th className="py-3 px-4">Preferred Code</th>
                      <th className="py-3 px-4">Contact Contact</th>
                      <th className="py-3 px-4">Available Bal</th>
                      <th className="py-3 px-4">Bonus Bal</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions / Adjust</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredAllProfiles.map((p: any) => {
                      const isEditing = editingUid === p.uid;
                      return (
                        <tr key={p.uid} className="hover:bg-slate-50/50">
                          <td className="py-3 px-4">
                            <span className="font-extrabold text-slate-800 block text-sm">{p.fullName}</span>
                            <span className="text-[10px] text-gray-500 font-mono block">{p.email}</span>
                            {p.address && <span className="text-[10px] text-slate-500 block break-words max-w-[200px]">📍 {p.address}</span>}
                            {p.nid && <span className="text-[10px] text-slate-600 font-mono block bg-slate-50 border px-1 w-max rounded mt-0.5">NID: {p.nid}</span>}
                            {p.referredBy && <span className="text-[10px] text-orange-700 font-mono block">Referred by: {p.referredBy}</span>}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editCode}
                                onChange={(e) => setEditCode(e.target.value)}
                                className="border border-indigo-200 bg-white font-mono uppercase font-black px-2 py-1 text-xs rounded outline-none focus:border-indigo-600 font-bold"
                              />
                            ) : (
                              <span className="font-mono bg-indigo-50 border border-indigo-100 text-indigo-700 font-black px-2.5 py-1 text-sm rounded">
                                {p.affiliateCode}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-slate-600 font-bold font-mono">{p.mobileNumber}</span>
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <div className="relative">
                                <span className="absolute left-1.5 inset-y-0 flex items-center text-gray-400 font-mono">৳</span>
                                <input
                                  type="number"
                                  value={editBalance}
                                  onChange={(e) => setEditBalance(Number(e.target.value))}
                                  className="border border-indigo-200 bg-white pl-4.5 pr-1 py-1 text-xs rounded w-20 outline-none focus:border-indigo-600 font-bold font-mono"
                                />
                              </div>
                            ) : (
                              <span className="font-extrabold text-emerald-600 text-sm">৳{(p.affiliateBalance || 0).toLocaleString()}</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <div className="relative">
                                <span className="absolute left-1.5 inset-y-0 flex items-center text-gray-400 font-mono">৳</span>
                                <input
                                  type="number"
                                  value={editBonusBalance}
                                  onChange={(e) => setEditBonusBalance(Number(e.target.value))}
                                  className="border border-indigo-200 bg-white pl-4.5 pr-1 py-1 text-xs rounded w-20 outline-none focus:border-indigo-600 font-bold font-mono"
                                />
                              </div>
                            ) : (
                              <span className="font-extrabold text-orange-600 text-sm">৳{(p.affiliateBonusBalance || 0).toLocaleString()}</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {isEditing ? (
                              <select
                                value={editStatus}
                                onChange={(e: any) => setEditStatus(e.target.value)}
                                className="border border-indigo-200 bg-white px-2 py-1 text-xs rounded outline-none focus:border-indigo-600 font-bold text-slate-700"
                              >
                                <option value="approved">Approved</option>
                                <option value="pending">Pending</option>
                                <option value="rejected">Rejected</option>
                              </select>
                            ) : (
                              <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-full ${
                                p.affiliateStatus === "approved" ? "bg-emerald-500 text-white" :
                                p.affiliateStatus === "pending" ? "bg-amber-500 text-white" : "bg-rose-500 text-white"
                              }`}>
                                {p.affiliateStatus || "approved"}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right">
                            {isEditing ? (
                              <div className="flex gap-2 justify-end">
                                <button
                                  onClick={() => handleSaveProfileEdit(p.uid)}
                                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black uppercase px-3 py-1.5 rounded-lg transition"
                                >
                                  Save Change
                                </button>
                                <button
                                  onClick={() => setEditingUid(null)}
                                  className="bg-slate-100 hover:bg-slate-200 text-slate-500 text-[10px] font-bold uppercase px-3 py-1.5 rounded-lg transition"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <div className="flex gap-2 justify-end">
                                <button
                                  onClick={() => handleStartEditProfile(p.uid, p)}
                                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-black uppercase px-3.5 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                                >
                                  <Edit2 className="w-3 h-3" /> Adjust
                                </button>
                                <button
                                  onClick={() => handleDeleteProfile(p.uid)}
                                  className="bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 text-[10px] font-black uppercase px-3.5 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                                  title="Delete Affiliate Profile / এফিলিয়েট ডিলিট করুন"
                                >
                                  <Trash2 className="w-3 h-3" /> Delete
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

      </div>

      {/* Custom Confirmation Modal */}
      {deletingUid && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-[9999]">
          <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-6">
              <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mb-4">
                <Trash2 className="w-6 h-6" />
              </div>
              <h4 className="text-base font-black text-slate-900 mb-1">
                Confirm Deletion / এফিলিয়েট ডিলিট নিশ্চিত করুন
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Are you sure you want to delete this affiliate profile? This user will lose their affiliate code, earnings, and status.
                <br />
                <span className="font-extrabold text-slate-700 block mt-2">
                  আপনি কি নিশ্চিত এই এফিলিয়েট প্রোফাইলটি মুছে ফেলতে চান? এর ফলে ব্যবহারকারী তার এফিলিয়েট কোড এবং ব্যালেন্স হারাবেন।
                </span>
              </p>
            </div>
            <div className="bg-slate-50 px-6 py-4 flex gap-3 justify-end border-t border-slate-100">
              <button
                type="button"
                onClick={() => setDeletingUid(null)}
                className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Cancel / বাতিল
              </button>
              <button
                type="button"
                onClick={() => {
                  const idToDelete = deletingUid;
                  setDeletingUid(null);
                  executeDeleteProfile(idToDelete);
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition shadow-sm hover:shadow cursor-pointer"
              >
                Yes, Delete / হ্যাঁ, ডিলিট করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-[9999] bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-800/50 flex items-center gap-2.5 animate-in slide-in-from-bottom-5 duration-300">
          <span className="text-sm">
            {notification.type === "success" ? "✨" : "⚠️"}
          </span>
          <span className="text-xs font-bold">{notification.message}</span>
        </div>
      )}
    </div>
  );
};
