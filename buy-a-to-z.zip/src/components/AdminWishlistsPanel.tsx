import React, { useState, useEffect } from "react";
import {
  Heart,
  TrendingUp,
  AlertTriangle,
  RefreshCw,
  Search,
  Plus,
  Phone,
  Mail,
  Eye,
  Check,
  Building,
  User,
  ShoppingBag,
  ExternalLink,
} from "lucide-react";
import { supabase } from "../lib/supabase"; // We'll double check this import in App.tsx if needed
import { Product, User as UserType } from "../types";

interface AdminWishlistsPanelProps {
  users: UserType[];
  products: Product[];
  onUpdateProductStock: (productId: string, newStock: number) => Promise<void>;
}

interface WishlistRecord {
  key: string;
  value: string[]; // List of product IDs
  updated_at?: string;
}

interface AggregatedProduct {
  product: Product;
  wishlistedBy: {
    userId: string;
    userName: string;
    email?: string;
    mobileNumber?: string;
    avatar?: string;
  }[];
  count: number;
}

interface UserWishlist {
  userId: string;
  user: UserType | null;
  productIds: string[];
  products: Product[];
  updatedAt?: string;
}

export function AdminWishlistsPanel({
  users,
  products,
  onUpdateProductStock,
}: AdminWishlistsPanelProps) {
  const [wishlists, setWishlists] = useState<WishlistRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSubTab, setActiveSubTab] = useState<"products" | "users">("products");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<"demand-desc" | "demand-asc" | "stock-asc" | "price-desc">("demand-desc");
  const [updatingStockId, setUpdatingStockId] = useState<string | null>(null);
  const [stockInputs, setStockInputs] = useState<{ [productId: string]: string }>({});

  const fetchWishlists = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("configs")
        .select("key, value, updated_at")
        .like("key", "wishlist_%");

      if (error) throw error;

      if (data) {
        // Format value, matching JSON array format
        const formattedData: WishlistRecord[] = data.map((row: any) => {
          let val: string[] = [];
          if (Array.isArray(row.value)) {
            val = row.value;
          } else if (typeof row.value === "string") {
            try {
              val = JSON.parse(row.value);
            } catch (e) {
              val = [];
            }
          }
          return {
            key: row.key,
            value: val,
            updated_at: row.updated_at,
          };
        });
        setWishlists(formattedData.filter((item) => item.value.length > 0));
      }
    } catch (err) {
      console.error("Error fetching wishlists from Supabase:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWishlists();
  }, []);

  // Helper: Extract uid from key ("wishlist_uid")
  const getUidFromKey = (key: string): string => {
    return key.replace("wishlist_", "");
  };

  // Helper: Find user details matching the uid
  const getUserDetails = (uid: string): UserType | null => {
    return users.find((u) => u.uid === uid) || null;
  };

  // 1. Process Aggregated Products
  const getAggregatedProducts = (): AggregatedProduct[] => {
    const aggMap: { [productId: string]: AggregatedProduct } = {};

    wishlists.forEach((wl) => {
      const uid = getUidFromKey(wl.key);
      const userObj = getUserDetails(uid);
      const userName = userObj?.fullName || userObj?.email || `ক্রেতা (${uid.substring(0, 5)})`;
      const email = userObj?.email || undefined;
      const mobileNumber = userObj?.mobileNumber || undefined;
      const avatar = userObj?.avatar || undefined;

      wl.value.forEach((prodId) => {
        const prod = products.find((p) => p.id === prodId);
        if (!prod) return; // Ignore deleted or invalid products

        if (!aggMap[prodId]) {
          aggMap[prodId] = {
            product: prod,
            wishlistedBy: [],
            count: 0,
          };
        }

        aggMap[prodId].wishlistedBy.push({
          userId: uid,
          userName,
          email,
          mobileNumber,
          avatar,
        });
        aggMap[prodId].count += 1;
      });
    });

    const sorted = Object.values(aggMap);
    if (sortBy === "demand-desc") {
      return sorted.sort((a, b) => b.count - a.count);
    } else if (sortBy === "demand-asc") {
      return sorted.sort((a, b) => a.count - b.count);
    } else if (sortBy === "stock-asc") {
      return sorted.sort((a, b) => (a.product.stock || 0) - (b.product.stock || 0));
    } else if (sortBy === "price-desc") {
      return sorted.sort((a, b) => Number(b.product.price) - Number(a.product.price));
    }
    return sorted;
  };

  // 2. Process User Wishlists
  const getUserWishlists = (): UserWishlist[] => {
    return wishlists.map((wl) => {
      const uid = getUidFromKey(wl.key);
      const userObj = getUserDetails(uid);
      const wlProducts = wl.value
        .map((pId) => products.find((p) => p.id === pId))
        .filter((p): p is Product => p !== undefined);

      return {
        userId: uid,
        user: userObj,
        productIds: wl.value,
        products: wlProducts,
        updatedAt: wl.updated_at,
      };
    }).filter((item) => item.products.length > 0);
  };

  const aggregatedData = getAggregatedProducts();
  const userWishlistsData = getUserWishlists();

  // Search filter
  const filteredAggregated = aggregatedData.filter((item) =>
    item.product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (item.product.category || "").toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUsers = userWishlistsData.filter((item) => {
    const q = searchQuery.toLowerCase();
    const nameMatch = (item.user?.fullName || "").toLowerCase().includes(q);
    const emailMatch = (item.user?.email || "").toLowerCase().includes(q);
    const phoneMatch = (item.user?.mobileNumber || "").toLowerCase().includes(q);
    const prodMatch = item.products.some((p) => p.name.toLowerCase().includes(q));
    return nameMatch || emailMatch || phoneMatch || prodMatch;
  });

  // Stock alert counts
  const outOfStockCount = aggregatedData.filter((item) => (item.product.stock || 0) === 0).length;
  const lowStockCount = aggregatedData.filter(
    (item) => (item.product.stock || 0) > 0 && (item.product.stock || 0) < 5
  ).length;

  const handleStockUpdateSubmit = async (productId: string) => {
    const inputVal = stockInputs[productId];
    if (!inputVal || isNaN(Number(inputVal))) return;
    const newStock = Math.max(0, parseInt(inputVal, 10));

    setUpdatingStockId(productId);
    try {
      await onUpdateProductStock(productId, newStock);
      // Feedback successfully updated, clear input
      setStockInputs((prev) => ({ ...prev, [productId]: "" }));
    } catch (e) {
      console.error(e);
      alert("স্টক আপডেট করতে সমস্যা হয়েছে।");
    } finally {
      setUpdatingStockId(null);
    }
  };

  const handleQuickAddStock = async (productId: string, currentStock: number, addAmount: number) => {
    const newStock = Math.max(0, (currentStock || 0) + addAmount);
    setUpdatingStockId(productId);
    try {
      await onUpdateProductStock(productId, newStock);
    } catch (e) {
      console.error(e);
      alert("স্টক আপডেট করতে সমস্যা হয়েছে।");
    } finally {
      setUpdatingStockId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header section with Stats Cards */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div>
          <h3 className="text-xl font-black text-daraz-text flex items-center gap-2">
            <Heart className="w-6 h-6 text-rose-500 fill-rose-500" />
            <span>Wishlist Demand Analysis (ক্রেতাদের উইশলিস্ট বিশ্লেষণ)</span>
          </h3>
          <p className="text-xs text-gray-500 mt-1 font-semibold">
            কোন কাস্টমার কোন প্রোডাক্ট উইশলিস্টে রাখছে তা নজরদারি করুন এবং চাহিদানুযায়ী স্টক নিয়ন্ত্রণ করুন।
          </p>
        </div>
        <button
          onClick={fetchWishlists}
          disabled={loading}
          className="bg-gray-50 border border-gray-200 text-gray-700 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 hover:bg-gray-100 transition-all self-start md:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          রিফ্রেশ করুন
        </button>
      </div>

      {/* Analytics Summary Widget */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-rose-50 rounded-xl flex items-center justify-center text-rose-500">
            <Heart className="w-6 h-6 fill-rose-500" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">মোট উইশলিস্ট সংখ্যা</p>
            <h4 className="text-2xl font-black text-slate-800">{wishlists.length} টি</h4>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-500">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">আকাঙ্ক্ষিত অনন্য পণ্য</p>
            <h4 className="text-2xl font-black text-slate-800">{aggregatedData.length} টি</h4>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-rose-100 shadow-sm bg-rose-50/20 flex items-center gap-4">
          <div className="w-12 h-12 bg-rose-100/50 rounded-xl flex items-center justify-center text-rose-600">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-rose-500 font-bold">উইশলিস্টেড ও স্টকআউট</p>
            <h4 className="text-2xl font-black text-rose-700">{outOfStockCount} টি পণ্য</h4>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-amber-100 shadow-sm bg-amber-50/20 flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-100/50 rounded-xl flex items-center justify-center text-amber-600">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-amber-600 font-bold">উইশলিস্টেড ও লো-স্টক (&lt;৫)</p>
            <h4 className="text-2xl font-black text-amber-700">{lowStockCount} টি পণ্য</h4>
          </div>
        </div>
      </div>

      {/* Tabs and Searching */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Toggle View Sub-Tabs */}
        <div className="bg-gray-100 p-1 rounded-xl flex gap-1 self-start">
          <button
            onClick={() => {
              setActiveSubTab("products");
              setSearchQuery("");
            }}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeSubTab === "products"
                ? "bg-white text-primary shadow-sm"
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            পণ্যভিত্তিক চাহিদা ({aggregatedData.length})
          </button>
          <button
            onClick={() => {
              setActiveSubTab("users");
              setSearchQuery("");
            }}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeSubTab === "users"
                ? "bg-white text-primary shadow-sm"
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <User className="w-4 h-4" />
            ক্রেতাভিত্তিক উইশলিস্ট ({userWishlistsData.length})
          </button>
        </div>

        {/* Filters and Search box */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 w-full lg:w-auto">
          {activeSubTab === "products" && (
            <div className="flex items-center gap-2 bg-white border border-gray-200 px-3 py-2 rounded-xl text-xs shadow-sm">
              <span className="text-gray-400 font-extrabold whitespace-nowrap">সর্টিং:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent font-bold text-slate-700 outline-none cursor-pointer"
              >
                <option value="demand-desc">চাহিদা (সর্বোচ্চ)</option>
                <option value="demand-asc">চাহিদা (সর্বনিম্ন)</option>
                <option value="stock-asc">স্টক (সর্বনিম্ন)</option>
                <option value="price-desc">মূল্য (সর্বোচ্চ)</option>
              </select>
            </div>
          )}

          {/* Dynamic Search Box */}
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder={
                activeSubTab === "products"
                  ? "পণ্যের নাম বা ক্যাটাগরি খুঁজুন..."
                  : "ক্রেতার নাম, ফোন, ইমেইল বা পণ্য খুঁজুন..."
              }
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-xl text-xs outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-semibold"
            />
          </div>
        </div>
      </div>

      {loading ? (
        <div className="bg-white p-20 rounded-2xl border border-gray-100 text-center flex flex-col items-center justify-center gap-3">
          <RefreshCw className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">উইশলিস্ট তথ্য লোড হচ্ছে...</p>
        </div>
      ) : activeSubTab === "products" ? (
        /* ================= SUB-TAB 1: PRODUCTS LIST ================= */
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {filteredAggregated.length === 0 ? (
            <div className="p-16 text-center text-gray-400">
              <Heart className="w-12 h-12 mx-auto mb-4 text-gray-200" />
              <p className="text-sm font-bold">কোন উইশলিস্টেড পণ্য পাওয়া যায়নি।</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100 text-[10px] font-black uppercase tracking-widest text-gray-400">
                    <th className="p-4 pl-6">পণ্য বিবরণ</th>
                    <th className="p-4">বিভাগ (Category)</th>
                    <th className="p-4 text-center">উইশলিস্টে সংযুক্ত সংখ্যা</th>
                    <th className="p-4 text-center">বর্তমান স্টক (Stock)</th>
                    <th className="p-4 text-right pr-6 min-w-[280px]">স্টক নিয়ন্ত্রণ (Stock Adjustment)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs text-slate-700">
                  {filteredAggregated.map((item) => {
                    const isOutOfStock = (item.product.stock || 0) === 0;
                    const isLowStock = !isOutOfStock && (item.product.stock || 0) < 5;

                    return (
                      <tr key={item.product.id} className="hover:bg-gray-50/50 transition-colors">
                        {/* Info Column */}
                        <td className="p-4 pl-6">
                          <div className="flex items-center gap-3">
                            <img
                              src={item.product.image || "/placeholder.jpg"}
                              alt={item.product.name}
                              className="w-12 h-12 object-cover rounded-lg border border-gray-100 flex-shrink-0"
                            />
                            <div>
                              <h5 className="font-bold text-slate-800 leading-snug line-clamp-2 max-w-sm">
                                {item.product.name}
                              </h5>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="font-bold text-emerald-600">
                                  ৳{Number(item.product.price).toLocaleString()}
                                </span>
                                {item.product.originalPrice && (
                                  <span className="text-[10px] text-gray-400 line-through">
                                    ৳{Number(item.product.originalPrice).toLocaleString()}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Category */}
                        <td className="p-4">
                          <span className="px-2.5 py-1 rounded-full bg-slate-100 text-[10px] font-bold text-slate-600">
                            {item.product.category || "No Category"}
                          </span>
                        </td>

                        {/* Demand Count */}
                        <td className="p-4 text-center">
                          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-50 text-rose-600 font-extrabold text-[13px]">
                            <Heart className="w-3.5 h-3.5 fill-rose-600" />
                            {item.count} বার উইশলিস্টেড
                          </div>
                        </td>

                        {/* Stock status */}
                        <td className="p-4 text-center">
                          {isOutOfStock ? (
                            <span className="inline-block px-2.5 py-1 rounded-full bg-red-100 text-red-700 font-bold text-[10px] uppercase">
                              Stock Out
                            </span>
                          ) : isLowStock ? (
                            <span className="inline-block px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 font-bold text-[10px] uppercase">
                              Low ({item.product.stock})
                            </span>
                          ) : (
                            <span className="inline-block px-2.5 py-1 rounded-full bg-green-100 text-green-700 font-bold text-[10px] uppercase">
                              In Stock ({item.product.stock})
                            </span>
                          )}
                        </td>

                        {/* Fast stock controls */}
                        <td className="p-4 text-right pr-6">
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-2">
                            {/* Fast increment buttons */}
                            <div className="flex gap-1">
                              <button
                                onClick={() => handleQuickAddStock(item.product.id, item.product.stock || 0, 5)}
                                disabled={updatingStockId === item.product.id}
                                className="px-2 py-1 border border-emerald-100 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 active:scale-95 disabled:opacity-50 text-[10px] rounded font-bold whitespace-nowrap transition-all"
                              >
                                +৫ স্টক
                              </button>
                              <button
                                onClick={() => handleQuickAddStock(item.product.id, item.product.stock || 0, 20)}
                                disabled={updatingStockId === item.product.id}
                                className="px-2 py-1 border border-emerald-200 bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 disabled:opacity-50 text-[10px] rounded font-bold whitespace-nowrap transition-all"
                              >
                                +২০ স্টক
                              </button>
                            </div>

                            {/* Manual entry */}
                            <div className="flex items-center border border-gray-200 rounded overflow-hidden h-7 max-w-[120px] self-end sm:self-auto">
                              <input
                                type="number"
                                min="0"
                                placeholder="স্টক..."
                                value={stockInputs[item.product.id] ?? ""}
                                onChange={(e) =>
                                  setStockInputs((prev) => ({
                                    ...prev,
                                    [item.product.id]: e.target.value,
                                  }))
                                }
                                className="w-14 h-full px-2 text-center text-xs outline-none focus:bg-gray-50 border-r border-gray-200"
                              />
                              <button
                                onClick={() => handleStockUpdateSubmit(item.product.id)}
                                disabled={updatingStockId === item.product.id}
                                className="px-2 bg-slate-800 text-white font-bold h-full flex items-center justify-center hover:bg-slate-900 active:scale-90 transition-all disabled:opacity-50"
                                title="সংরক্ষণ করুন"
                              >
                                <Check className="w-3 h-3 stroke-[3]" />
                              </button>
                            </div>
                          </div>
                          
                          {/* Wishlisted customers breakdown inside product */}
                          <div className="mt-2 text-left">
                            <span className="text-[9px] text-gray-400 font-semibold block uppercase">
                              আগ্রহী ক্রেতাগণ:
                            </span>
                            <div className="flex flex-wrap gap-1 mt-1 max-w-lg">
                              {item.wishlistedBy.map((buyer, bIdx) => (
                                <div
                                  key={bIdx}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-gray-50 text-[9px] text-gray-600 font-bold border border-gray-100"
                                >
                                  <User className="w-2.5 h-2.5 text-gray-400" />
                                  <span>{buyer.userName}</span>
                                  {buyer.mobileNumber && (
                                    <span className="font-mono text-[8px] text-gray-400">({buyer.mobileNumber})</span>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        /* ================= SUB-TAB 2: CUSTOMERS LIST ================= */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredUsers.length === 0 ? (
            <div className="col-span-2 bg-white p-16 rounded-2xl border border-gray-100 text-center text-gray-400">
              <User className="w-12 h-12 mx-auto mb-4 text-gray-200" />
              <p className="text-sm font-bold">কোন ক্রেতার সংরক্ষিত উইশলিস্ট পাওয়া যায়নি।</p>
            </div>
          ) : (
            filteredUsers.map((item) => {
              const displayName = item.user?.fullName || "Guest Customer (গেস্ট)";
              const displayMobile = item.user?.mobileNumber || "No Phone Number";
              const displayEmail = item.user?.email || "No Email Address";
              const displayAvatar = item.user?.avatar;

              return (
                <div
                  key={item.userId}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4 hover:border-rose-100 hover:shadow-md transition-all duration-300 flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    {/* User Profile Header */}
                    <div className="flex items-start gap-3 border-b border-gray-50 pb-3">
                      <div className="w-10 h-10 rounded-full bg-slate-50 border border-gray-100 flex items-center justify-center overflow-hidden shrink-0">
                        {displayAvatar ? (
                          <img src={displayAvatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <User className="w-5 h-5 text-gray-400" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="font-bold text-slate-800 text-sm truncate leading-tight">
                          {displayName}
                        </h4>
                        <div className="flex flex-col gap-0.5 mt-1 font-semibold text-[10px] text-gray-400">
                          {item.user?.mobileNumber && (
                            <span className="flex items-center gap-1 font-mono">
                              <Phone className="w-3 h-3 text-slate-400" /> {displayMobile}
                            </span>
                          )}
                          {item.user?.email && (
                            <span className="flex items-center gap-1 truncate">
                              <Mail className="w-3 h-3 text-slate-400" /> {displayEmail}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="px-2.5 py-1 rounded bg-rose-50 border border-rose-100 text-[10px] text-rose-600 font-black uppercase">
                        {item.products.length} Items Wishlisted
                      </div>
                    </div>

                    {/* Products Wishlisted by User */}
                    <div>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-2">
                        সংরক্ষিত পণ্য তালিকা
                      </p>
                      <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                        {item.products.map((p) => {
                          const isOutOfStock = (p.stock || 0) === 0;
                          return (
                            <div
                              key={p.id}
                              className="flex items-center gap-3 p-2 rounded-xl bg-gray-50 border border-gray-100 hover:bg-slate-50/50 transition-colors"
                            >
                              <img
                                src={p.image || "/placeholder.jpg"}
                                alt={p.name}
                                className="w-9 h-9 object-cover rounded-lg border border-gray-200 shrink-0"
                              />
                              <div className="min-w-0 flex-1">
                                <h5 className="font-bold text-slate-700 text-xs truncate leading-snug">
                                  {p.name}
                                </h5>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="font-bold text-emerald-600 text-[11px]">
                                    ৳{Number(p.price).toLocaleString()}
                                  </span>
                                  {isOutOfStock ? (
                                    <span className="text-[9px] px-1.5 py-0.2 bg-red-100 text-red-600 font-extrabold rounded">
                                      স্টক আউট
                                    </span>
                                  ) : (
                                    <span className="text-[9px] px-1.5 py-0.2 bg-green-50 text-green-600 font-bold rounded">
                                      স্টক: {p.stock}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Footer metadata */}
                  {item.updatedAt && (
                    <div className="pt-3 border-t border-gray-50 text-[9px] font-mono text-gray-400 text-right">
                      সর্বশেষ আপডেট: {new Date(item.updatedAt).toLocaleString("bn-BD")}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
