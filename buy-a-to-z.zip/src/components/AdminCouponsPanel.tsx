import React, { useState } from "react";
import { 
  Ticket, 
  Plus, 
  Trash2, 
  Edit2, 
  Check, 
  X, 
  Percent, 
  DollarSign, 
  AlertCircle, 
  Eye, 
  Search,
  CheckCircle2,
  XCircle,
  HelpCircle
} from "lucide-react";
import { Coupon } from "../types";

interface AdminCouponsPanelProps {
  coupons: Coupon[];
  saveCoupons: (updated: Coupon[]) => Promise<void>;
}

export const AdminCouponsPanel: React.FC<AdminCouponsPanelProps> = ({
  coupons,
  saveCoupons
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states (shared between add and edit)
  const [code, setCode] = useState("");
  const [discountType, setDiscountType] = useState<"flat" | "percentage">("flat");
  const [discountValue, setDiscountValue] = useState<number>(100);
  const [minPurchaseAmount, setMinPurchaseAmount] = useState<number>(1000);
  const [isActive, setIsActive] = useState(true);
  const [description, setDescription] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [formError, setFormError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filtered coupons
  const filteredCoupons = coupons.filter(coupon => 
    coupon.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (coupon.description && coupon.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const resetForm = () => {
    setCode("");
    setDiscountType("flat");
    setDiscountValue(100);
    setMinPurchaseAmount(1000);
    setIsActive(true);
    setDescription("");
    setExpiryDate("");
    setFormError("");
  };

  const handleStartAdd = () => {
    resetForm();
    setIsAdding(true);
    setEditingId(null);
  };

  const handleStartEdit = (coupon: Coupon) => {
    setCode(coupon.code);
    setDiscountType(coupon.discountType);
    setDiscountValue(coupon.discountValue);
    setMinPurchaseAmount(coupon.minPurchaseAmount);
    setIsActive(coupon.isActive);
    setDescription(coupon.description || "");
    setExpiryDate(coupon.expiryDate || "");
    setEditingId(coupon.id);
    setIsAdding(false);
    setFormError("");
  };

  const validateForm = (): boolean => {
    if (!code.trim()) {
      setFormError("কুপন কোডটি আবশ্যক (Coupon Code is required)");
      return false;
    }
    const safeCode = code.toUpperCase().trim();
    
    // Check duplication (if adding or if code changed on edit)
    const existing = coupons.find(c => c.code.toUpperCase() === safeCode);
    if (existing && (isAdding || (editingId && existing.id !== editingId))) {
      setFormError("এই কুপন কোডটি ইতিমধ্যে ব্যবহার করা হয়েছে (This coupon code is already used)");
      return false;
    }

    if (discountValue <= 0) {
      setFormError("ডিসকাউন্ট ভ্যালু অবশ্যই ০ থেকে বড় হতে হবে (Discount value must be greater than 0)");
      return false;
    }

    if (discountType === "percentage" && discountValue > 100) {
      setFormError("শতকরা ডিসকাউন্ট ১০০% এর বেশি হতে পারে না (Percentage discount cannot exceed 100%)");
      return false;
    }

    if (minPurchaseAmount < 0) {
      setFormError("সর্বনিম্ন অর্ডারের পরিমাণ ০ বা তার বেশি হতে হবে (Minimum purchase amount must be 0 or more)");
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      let updatedCoupons: Coupon[];
      const finalizedCode = code.trim().toUpperCase();

      if (isAdding) {
        const newCoupon: Coupon = {
          id: `coup-${Date.now()}`,
          code: finalizedCode,
          discountType,
          discountValue,
          minPurchaseAmount,
          isActive,
          description: description.trim() || undefined,
          expiryDate: expiryDate ? expiryDate : undefined
        };
        updatedCoupons = [...coupons, newCoupon];
      } else {
        updatedCoupons = coupons.map(c => 
          c.id === editingId 
            ? {
                ...c,
                code: finalizedCode,
                discountType,
                discountValue,
                minPurchaseAmount,
                isActive,
                description: description.trim() || undefined,
                expiryDate: expiryDate ? expiryDate : undefined
              }
            : c
        );
      }

      await saveCoupons(updatedCoupons);
      setIsAdding(false);
      setEditingId(null);
      resetForm();
    } catch (err: any) {
      setFormError(err.message || "সংরক্ষণ করতে ব্যর্থ হয়েছে (Failed to save)");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("আপনি কি নিশ্চিতভাবে এই কুপনটি ডিলিট করতে চান? (Are you sure you want to delete this coupon?)")) {
      return;
    }

    try {
      const updatedCoupons = coupons.filter(c => c.id !== id);
      await saveCoupons(updatedCoupons);
    } catch (err: any) {
      alert("ডিলিট করতে সমস্যা হয়েছে: " + err.message);
    }
  };

  const handleToggleActive = async (coupon: Coupon) => {
    const updatedCoupons = coupons.map(c => 
      c.id === coupon.id 
        ? { ...c, isActive: !c.isActive } 
        : c
    );
    try {
      await saveCoupons(updatedCoupons);
    } catch (err: any) {
      alert("স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে: " + err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Upper Status / Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Ticket className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-black text-daraz-text leading-tight uppercase">
              Coupon Code Release System (কুপন কোড ব্যবস্থাপনা)
            </h3>
          </div>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mt-1">
            Manage your store's coupon codes, discounts, and minimum limit rules
          </p>
        </div>

        <button
          onClick={handleStartAdd}
          disabled={isAdding}
          className="text-xs bg-primary text-white px-4 py-2 rounded-xl font-bold hover:scale-[1.02] flex items-center gap-1.5 transition-all shadow-sm shadow-green-100 disabled:opacity-50"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          Create New Coupon (নতুন কুপন যোগ করুন)
        </button>
      </div>

      {/* Editor Panel (Show when adding or editing) */}
      {(isAdding || editingId) && (
        <form 
          onSubmit={handleSubmit}
          className="bg-white border-2 border-primary/10 rounded-2xl p-6 shadow-sm space-y-6 animate-fadeIn"
        >
          <div className="flex justify-between items-center border-b border-gray-100 pb-3">
            <h4 className="font-black text-sm text-daraz-text tracking-wider uppercase flex items-center gap-1.5">
              <Ticket className="w-4 h-4 text-primary" />
              {isAdding ? "✨ Create Coupon Releases" : "📝 Edit Existing Coupon"}
            </h4>
            <button
              type="button"
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
                resetForm();
              }}
              className="text-gray-400 hover:text-gray-600 transition-all text-xl"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {formError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs flex items-center gap-2 font-bold animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Promo Code Input */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-500 block">
                Promo Code (কোড নাম - e.g. EID2026, BANGLA10)
              </label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase().replace(/\s+/g, ""))}
                placeholder="EID500"
                className="w-full border border-gray-200 rounded px-4 py-2.5 text-sm outline-none focus:border-primary uppercase font-mono font-bold"
              />
            </div>

            {/* Discount Type */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-500 block">
                Discount Type (ডিসকাউন্টের ধরন)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setDiscountType("flat")}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                    discountType === "flat"
                      ? "bg-slate-100 border-slate-300 text-slate-800"
                      : "bg-white border-gray-100 text-gray-500 hover:bg-gray-50"
                  }`}
                >
                  <DollarSign className="w-3.5 h-3.5 text-primary" /> Flat Amount (৳)
                </button>
                <button
                  type="button"
                  onClick={() => setDiscountType("percentage")}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                    discountType === "percentage"
                      ? "bg-slate-100 border-slate-300 text-slate-800"
                      : "bg-white border-gray-100 text-gray-500 hover:bg-gray-50"
                  }`}
                >
                  <Percent className="w-3.5 h-3.5 text-primary" /> Percentage (%)
                </button>
              </div>
            </div>

            {/* Discount Value */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-500 block">
                Discount Value (টাকার পরিমাণ বা শতকরা পরিমাণ)
              </label>
              <div className="relative">
                <input
                  type="number"
                  required
                  min={1}
                  value={discountValue}
                  onChange={(e) => setDiscountValue(Math.max(0, parseInt(e.target.value) || 0))}
                  placeholder={discountType === "flat" ? "500" : "15"}
                  className="w-full border border-gray-200 rounded pl-4 pr-8 py-2.5 text-sm font-bold outline-none focus:border-primary"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">
                  {discountType === "flat" ? "৳" : "%"}
                </span>
              </div>
            </div>

            {/* Min Purchase Amount */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-500 block">
                Min Purchase Limit (সর্বনিম্ন কেনাকাটার পরিমাণ)
              </label>
              <div className="relative">
                <input
                  type="number"
                  required
                  min={0}
                  value={minPurchaseAmount}
                  onChange={(e) => setMinPurchaseAmount(Math.max(0, parseInt(e.target.value) || 0))}
                  placeholder="1000"
                  className="w-full border border-gray-200 rounded pl-4 pr-10 py-2.5 text-sm font-bold outline-none focus:border-primary"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">
                  ৳ min
                </span>
              </div>
            </div>

            {/* Expiry Date */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-500 block">
                Expiry Date (মেয়াদ শেষ হওয়ার তারিখ - Optional)
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full border border-gray-200 rounded px-4 py-2 text-sm outline-none focus:border-primary font-bold"
              />
            </div>

            {/* Status Checkbox */}
            <div className="space-y-1 flex flex-col justify-end">
              <div className="flex items-center gap-2 py-3">
                <input
                  type="checkbox"
                  id="couponActiveState"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="w-4 h-4 text-primary focus:ring-primary border-gray-300 rounded"
                />
                <label
                  htmlFor="couponActiveState"
                  className="text-xs font-bold text-gray-700 select-none uppercase tracking-tighter"
                >
                  Active Right Now? (কুপনটি চালু থাকবে?)
                </label>
              </div>
            </div>

            {/* Description / Summary */}
            <div className="space-y-1 md:col-span-3">
              <label className="text-[10px] font-black uppercase text-gray-500 block">
                Coupon Display Description (গ্রাহকদের দেখানোর জন্য বিবরণ)
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="৳১০০০ এর বেশি অর্ডার করলে ফ্ল্যাট ৳১০০ ডিসকাউন্ট!"
                className="w-full border border-gray-200 rounded px-4 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-gray-50">
            <button
              type="button"
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
                resetForm();
              }}
              className="px-4 py-2 text-xs border border-gray-200 rounded-xl font-bold bg-white text-gray-600 hover:bg-gray-50 transition-all active:scale-95"
            >
              Cancel (বাতিল করুন)
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 text-xs bg-primary text-white rounded-xl font-bold hover:opacity-90 transition-all active:scale-95 shadow-sm shadow-green-100 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              {isSubmitting ? "Saving..." : "Save Coupon (সংরক্ষণ করুন)"}
            </button>
          </div>
        </form>
      )}

      {/* Main Grid View */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Filtering & Listing tools */}
        <div className="p-4 bg-gray-50/50 border-b border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by code or description..."
              className="w-full pl-10 pr-4 py-2 text-xs bg-white border border-gray-200 rounded-xl outline-none focus:border-primary font-medium"
            />
          </div>

          <div className="text-xs font-bold text-gray-500 uppercase tracking-wider">
            Total Released: <span className="text-primary font-black">{coupons.length}</span> coupons
          </div>
        </div>

        {/* Coupons List Grid */}
        {filteredCoupons.length === 0 ? (
          <div className="p-12 text-center text-gray-400 flex flex-col items-center justify-center gap-3">
            <Ticket className="w-10 h-10 text-gray-200" />
            <div>
              <p className="font-bold text-sm text-gray-600">কোন কুপন কোড পাওয়া যায়নি!</p>
              <p className="text-xs mt-1">কুপন কোড যোগ করতে ওপরের "Create New Coupon" বাটনে ক্লিক করুন।</p>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 uppercase text-[10px] text-gray-400 font-bold tracking-widest border-b border-gray-100">
                  <th className="p-4">Coupon Code</th>
                  <th className="p-4">Discount Applied</th>
                  <th className="p-4">Minimum Order Requirement</th>
                  <th className="p-4">Expiry Date</th>
                  <th className="p-4">Display Label/Description</th>
                  <th className="p-4 text-center">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-xs">
                {filteredCoupons.map((coupon) => (
                  <tr 
                    key={coupon.id} 
                    className={`hover:bg-slate-50/50 transition-all ${!coupon.isActive ? "bg-gray-50/30 text-gray-400" : ""}`}
                  >
                    {/* Code */}
                    <td className="p-4 font-mono font-bold tracking-wider">
                      <div className="flex items-center gap-2">
                        <div className={`p-1.5 rounded-lg ${coupon.isActive ? "bg-primary/10 text-primary" : "bg-gray-100 text-gray-400"}`}>
                          <Ticket className="w-3.5 h-3.5" />
                        </div>
                        <span className="text-sm font-black text-daraz-text">{coupon.code}</span>
                      </div>
                    </td>

                    {/* Discount */}
                    <td className="p-4 font-bold text-slate-800">
                      {coupon.discountType === "flat" ? (
                        <span className="flex items-center gap-1">
                          ৳{coupon.discountValue} <span className="text-[10px] text-gray-400 font-normal">Flat</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-emerald-600">
                          {coupon.discountValue}% <span className="text-[10px] text-gray-400 font-normal">Percentage</span>
                        </span>
                      )}
                    </td>

                    {/* Min Spend */}
                    <td className="p-4 font-bold text-slate-700">
                      ৳{coupon.minPurchaseAmount.toLocaleString()}
                    </td>

                    {/* Expiry Date */}
                    <td className="p-4 font-semibold text-slate-700 font-mono text-[11px]">
                      {coupon.expiryDate ? (
                        (() => {
                           const today = new Date().toISOString().split('T')[0];
                           const isExpired = coupon.expiryDate < today;
                           return (
                             <span className={isExpired ? "text-red-500 font-bold bg-red-50 px-2 py-1 rounded-md" : "text-blue-600 bg-blue-50 px-2 py-1 rounded-md"}>
                               {coupon.expiryDate} {isExpired && "⚠️ Expired"}
                             </span>
                           );
                        })()
                      ) : (
                        <span className="text-gray-300 italic">No Limit</span>
                      )}
                    </td>

                    {/* Description */}
                    <td className="p-4 max-w-xs truncate text-[11px] text-gray-600 font-medium">
                      {coupon.description || (
                        <span className="text-gray-300 italic">No custom label</span>
                      )}
                    </td>

                    {/* Live status */}
                    <td className="p-4 text-center">
                      <button
                        type="button"
                        onClick={() => handleToggleActive(coupon)}
                        className={`inline-flex items-center gap-1 py-1 px-3 rounded-full text-[10px] font-black uppercase tracking-wider transition-all border ${
                          coupon.isActive
                            ? "bg-emerald-50 text-emerald-600 border-emerald-100 hover:bg-emerald-100"
                            : "bg-red-50 text-red-500 border-red-100 hover:bg-red-100"
                        }`}
                      >
                        {coupon.isActive ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 stroke-[2.5]" />
                            Active
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3 h-3 stroke-[2.5]" />
                            Inactive
                          </>
                        )}
                      </button>
                    </td>

                    {/* Actions */}
                    <td className="p-4 text-right">
                      <div className="inline-flex gap-2">
                        <button
                          onClick={() => handleStartEdit(coupon)}
                          className="bg-white border border-gray-200 text-daraz-text p-2 rounded-xl hover:border-blue-500 hover:text-blue-500 transition-all active:scale-95"
                          title="Edit Code"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(coupon.id)}
                          className="bg-red-50 text-red-500 p-2 rounded-xl hover:bg-red-500 hover:text-white border border-red-100 hover:border-red-500 transition-all active:scale-95"
                          title="Delete Code"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Instructional guidelines */}
      <div className="bg-blue-50/50 border border-blue-100 p-6 rounded-2xl flex gap-4 leading-relaxed">
        <HelpCircle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
        <div className="space-y-1.5 text-xs text-blue-800">
          <h4 className="font-black uppercase tracking-wider">How to redeem & deploy?</h4>
          <p>
            ১. গ্রাহকের কার্ট ভ্যালু যখন সর্বনিম্ন অর্ডারের লিমিট অতিক্রম করবে, তখনই কুপনটি পেমেন্ট বা চেকআউট সেকশনে ইনপুট দিয়ে সক্রিয় করা যাবে।
          </p>
          <p>
            ২. কুপন থেকে প্রাপ্ত ডিসকাউন্ট সিস্টেম কার্ট টোটাল এবং ডেলিভারি চার্জ হিসাব করার সময় স্বয়ংক্রিয়ভাবে মোট হিসাব থেকে কেটে ফেলবে।
          </p>
          <p>
            ৩. কোনো কুপন ইনপুট করার পর যদি কার্ট থেকে কোনো পণ্য ডিলিট করা হয় এবং মিনিমাম কার্ট লিমিট আর ম্যাচ না করে, তাহলে কুপনটি বাতিল হয়ে যাবে।
          </p>
        </div>
      </div>
    </div>
  );
};
