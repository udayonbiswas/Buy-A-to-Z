import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import PDFDocument from "pdfkit";
import fs from "fs";
import multer from "multer";

dotenv.config();

function generateInvoicePdf(order: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 50, size: "A4" });
      const chunks: Buffer[] = [];
      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", (err) => reject(err));

      // Brand Identity Accent Header
      doc.rect(0, 0, 595, 12).fill("#f85606");

      // Title & Logo
      doc.fillColor("#1e293b")
         .font("Helvetica-Bold")
         .fontSize(22)
         .text("Buy A to Z", 50, 40)
         .font("Helvetica")
         .fontSize(9)
         .fillColor("#64748b")
         .text("E-commerce Trading & Logistics", 50, 65)
         .text("Email: support@buyatoz.live", 50, 77);

      // Invoice Reference (Top Right)
      doc.font("Helvetica-Bold")
         .fontSize(12)
         .fillColor("#1e293b")
         .text("DEED OF PROCURE / INVOICE", 300, 40, { align: "right" })
         .font("Helvetica")
         .fontSize(9)
         .fillColor("#475569")
         .text(`Invoice ID: ${order.id || "N/A"}`, 300, 58, { align: "right" })
         .text(`Date Issued: ${order.timestamp ? new Date(order.timestamp).toLocaleString("en-US", { timeZone: "Asia/Dhaka", year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: true }) : new Date().toLocaleString("en-US", { timeZone: "Asia/Dhaka", year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: true })}`, 300, 71, { align: "right" })
         .font("Helvetica-Bold")
         .fillColor("#16a34a")
         .text(`Status: ${String(order.status || "processing").toUpperCase()}`, 300, 84, { align: "right" });

      // Horizontal separator
      doc.moveTo(50, 110).lineTo(545, 110).lineWidth(1).strokeColor("#e2e8f0").stroke();

      // Billed To & Shipped To side-by-side
      doc.fillColor("#475569")
         .font("Helvetica-Bold")
         .fontSize(9)
         .text("CUSTOMER INVOICE TO:", 50, 125);
      
      doc.fillColor("#0f172a")
         .font("Helvetica-Bold")
         .fontSize(10)
         .text(order.customerName || "Valued Customer", 50, 137);

      doc.fillColor("#334155")
         .font("Helvetica")
         .fontSize(9)
         .text(`Contact: ${order.customerMobile || "N/A"}`, 50, 151)
         .text(`Email: ${order.customerEmail || "N/A"}`, 50, 163);

      // Delivery Destination
      const delivery = order.delivery || {};
      doc.fillColor("#475569")
         .font("Helvetica-Bold")
         .fontSize(9)
         .text("SHIPMENT DESTINATION:", 300, 125);

      const addressStr = `${delivery.address || ""}, ${delivery.area || ""}, ${delivery.city || ""}`;
      doc.fillColor("#0f172a")
         .font("Helvetica")
         .fontSize(9)
         .text(addressStr || "N/A", 300, 137, { width: 245, lineGap: 2 });

      doc.fillColor("#334155")
         .fontSize(9)
         .text(`Shipping Mode: ${delivery.deliveryType === "express" ? "Express Delivery" : "Standard Delivery"}`, 300, 175)
         .text(`Payment Gateway: ${String(order.payment?.method || "Cash On Delivery").toUpperCase()}`, 300, 187);

      // Section Break
      doc.moveTo(50, 210).lineTo(545, 210).lineWidth(1).strokeColor("#e2e8f0").stroke();

      doc.fillColor("#1e293b")
         .font("Helvetica-Bold")
         .fontSize(11)
         .text("ITEMS SPECIFICATION & DETAIL", 50, 225);

      // Table Header row background
      let y = 245;
      doc.rect(50, y, 495, 20).fill("#1e293b");

      doc.fillColor("#ffffff")
         .font("Helvetica-Bold")
         .fontSize(8)
         .text("Item / Catalog Description", 60, y + 6)
         .text("Quantity", 360, y + 6, { width: 45, align: "center" })
         .text("Unit Price", 410, y + 6, { width: 60, align: "right" })
         .text("Item Total", 480, y + 6, { width: 60, align: "right" });

      y += 20;

      const items = order.items || [];
      items.forEach((item: any, idx: number) => {
        // Alternating row backgrounds
        if (idx % 2 === 1) {
          doc.rect(50, y, 495, 22).fill("#f8fafc");
        }

        doc.fillColor("#1e293b")
           .font("Helvetica-Bold")
           .fontSize(8)
           .text(item.name || "Product Item", 60, y + 7, { width: 290, height: 11, ellipsis: true });

        // Show variation hints if exist
        if (item.selectedSize || item.selectedColor) {
          const varAttr = [
            item.selectedSize ? `Size: ${item.selectedSize}` : "",
            item.selectedColor ? `Color: ${item.selectedColor}` : ""
          ].filter(Boolean).join(" | ");
          doc.fillColor("#64748b")
             .font("Helvetica")
             .fontSize(7)
             .text(varAttr, 60, y + 17, { width: 290 });
        }

        doc.fillColor("#334155")
           .font("Helvetica")
           .fontSize(8)
           .text(String(item.quantity || 1), 360, y + 7, { width: 45, align: "center" })
           .text(`BDT ${Number(item.price || 0).toLocaleString()}`, 410, y + 7, { width: 60, align: "right" })
           .text(`BDT ${Number((item.price || 0) * (item.quantity || 1)).toLocaleString()}`, 480, y + 7, { width: 60, align: "right" });

        // Separator line
        doc.moveTo(50, y + 22).lineTo(545, y + 22).lineWidth(0.5).strokeColor("#e2e8f0").stroke();
        y += 22;
      });

      // Calc aggregates
      const subtotal = items.reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0);
      const isFreeDelivery = delivery.deliveryType === "free";
      const originalShippingCharge = delivery.deliveryType === "express" ? 120 : 50;
      const shippingCharge = isFreeDelivery ? 0 : originalShippingCharge;
      
      const couponDiscVal = order.couponDiscount || 0;
      const totalWithoutPromo = subtotal + shippingCharge - couponDiscVal;
      const totalAmount = order.total || Math.max(0, totalWithoutPromo);
      const promoDiscVal = Math.max(0, totalWithoutPromo - totalAmount);

      const showCoupon = couponDiscVal > 0;
      const showPromo = promoDiscVal > 0;

      const rows: Array<{ label: string; val: string; color: string }> = [];
      rows.push({ label: "Subtotal:", val: `BDT ${subtotal.toLocaleString()}`, color: "#475569" });
      
      if (order.vatAmount && order.vatAmount > 0) {
        rows.push({ label: "VAT (ভ্যাট):", val: `BDT ${Number(order.vatAmount).toLocaleString()}`, color: "#475569" });
      }
      
      rows.push({ label: "Delivery Charge:", val: `BDT ${originalShippingCharge.toLocaleString()}`, color: "#475569" });

      if (isFreeDelivery) {
        rows.push({ label: "Delivery Discount:", val: `-BDT ${originalShippingCharge.toLocaleString()}`, color: "#16a34a" });
      }

      if (showCoupon) {
        rows.push({ label: `Coupon Discount (${order.couponCode || "Coupon"}):`, val: `-BDT ${couponDiscVal.toLocaleString()}`, color: "#16a34a" });
      }

      if (showPromo) {
        rows.push({ label: "Special/New User Disc:", val: `-BDT ${promoDiscVal.toLocaleString()}`, color: "#16a34a" });
      }

      y += 10;
      const boxHeight = rows.length * 14 + 25; // 25px top/bottom padding + some room for Grand Total

      // Right summary details box
      doc.rect(340, y, 205, boxHeight).fill("#f8fafc");
      doc.rect(340, y, 205, boxHeight).lineWidth(1).strokeColor("#e2e8f0").stroke();

      let currentTextY = y + 8;
      rows.forEach(row => {
        doc.fillColor(row.color)
           .font(row.color === "#16a34a" ? "Helvetica-Bold" : "Helvetica")
           .fontSize(8)
           .text(row.label, 350, currentTextY)
           .text(row.val, 450, currentTextY, { align: "right", width: 85 });
        currentTextY += 14;
      });

      // Line separator before grand total
      doc.moveTo(345, currentTextY).lineTo(540, currentTextY).lineWidth(0.5).strokeColor("#cbd5e1").stroke();

      const totalY = currentTextY + 5;
      doc.fillColor("#f85606")
         .font("Helvetica-Bold")
         .fontSize(9)
         .text("Grand Total:", 350, totalY)
         .text(`BDT ${totalAmount.toLocaleString()}`, 450, totalY, { align: "right", width: 85 });

      // Guarantee & verification text (bottom left of summary)
      doc.fillColor("#64748b")
         .font("Helvetica-Bold")
         .fontSize(7)
         .text("TERMS & SATISFACTION VERIFICATION", 50, y + 8)
         .font("Helvetica")
         .text("Thanks for procurement. All products are sourced from certified catalog suppliers. Please retain this invoice deed for standard 14-day replacement, logistics tracing or support requests.", 50, y + 18, { width: 270, lineGap: 1.5 });

      // Bottom Footer decoration
      doc.moveTo(50, 450).lineTo(545, 450).lineWidth(1).strokeColor("#cbd5e1").stroke();

      doc.fillColor("#94a3b8")
         .font("Helvetica")
         .fontSize(7.5)
         .text("This document constitutes a legally valid merchant procurement confirmation. Standard platform terms apply.", 50, 462, { align: "center", width: 495 })
         .font("Helvetica-Bold")
         .fillColor("#64748b")
         .text("© 2026 Buy A to Z Ecommerce. All rights reserved.", 50, 474, { align: "center", width: 495 });

      doc.end();
    } catch (e) {
      reject(e);
    }
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "150mb" }));
  app.use(express.urlencoded({ limit: "150mb", extended: true }));

  // Create upload folder if not exists
  const uploadDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  // Serve static uploaded files
  app.use("/uploads", express.static(uploadDir));

  // Configure Multer for video uploads
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      const ext = path.extname(file.originalname);
      cb(null, `${file.fieldname}-${uniqueSuffix}${ext}`);
    }
  });

  const upload = multer({
    storage: storage,
    limits: {
      fileSize: 100 * 1024 * 1024, // 100 MB Limit (allows videos up to 100MB, satisfying the 50MB minimum)
    },
    fileFilter: (req, file, cb) => {
      if (file.mimetype.startsWith("video/")) {
        cb(null, true);
      } else {
        cb(new Error("শুধুমাত্র ভিডিও ফাইল আপলোড করা যাবে!"));
      }
    }
  });

  // API Endpoint for video upload (At least 50MB video supported)
  app.post("/api/upload-video", (req, res) => {
    upload.single("video")(req, res, (err) => {
      if (err instanceof multer.MulterError) {
        if (err.code === "LIMIT_FILE_SIZE") {
          return res.status(400).json({ success: false, error: "ফাইলের সাইজ অতি বৃহৎ (সর্বোচ্চ ১০০ মেগাবাইট)!" });
        }
        return res.status(400).json({ success: false, error: err.message });
      } else if (err) {
        return res.status(400).json({ success: false, error: err.message });
      }

      if (!req.file) {
        return res.status(400).json({ success: false, error: "কোন ফাইল পাওয়া যায়নি!" });
      }

      const videoUrl = `/uploads/${req.file.filename}`;
      res.json({ success: true, videoUrl });
    });
  });

  // 📧 Email & 📱 SMS Notification Endpoints
  const formatSmtpError = (error: any): string => {
    const errMsg = error?.message || "";
    if (
      errMsg.includes("535") || 
      errMsg.toLowerCase().includes("invalid login") || 
      errMsg.includes("EAUTH")
    ) {
      return "জিমেইল SMTP লগইন ব্যর্থ হয়েছে (535-5.7.8)। গুগলের সিকিউরিটি পলিসি অনুযায়ী আপনার সাধারণ জিমেইল পাসওয়ার্ড দিয়ে লগইন করা যাবে না। অনুগ্রহ করে আপনার গুগল অ্যাকাউন্ট সেটিংসে (Google Account > Security > 2-Step Verification) গিয়ে 2-Step Verification অন করুন এবং একটি 'App Password' (১৬ সংখ্যার কোড) তৈরি করে সেটি EMAIL_PASS হিসেবে সেটিংস > সিক্রেটস এ বসিয়ে দিন।";
    }
    return errMsg;
  };

  app.post("/api/send-email", async (req, res) => {
    const { to, subject, html, order } = req.body;

    try {
      const emailUser = process.env.EMAIL_USER?.trim();
      const emailPass = process.env.EMAIL_PASS?.replace(/\s/g, "");

      if (!emailUser || !emailPass) {
        throw new Error("SMTP configuration missing (EMAIL_USER/PASS)");
      }

      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: { user: emailUser, pass: emailPass },
        pool: true,
        maxConnections: 5,
        maxMessages: 100,
        connectionTimeout: 3000, // 3s connection timeout
        greetingTimeout: 3000,   // 3s greeting timeout
        socketTimeout: 5000,     // 5s socket timeout
      });

      const attachments = [];
      if (order) {
        try {
          const pdfBuffer = await generateInvoicePdf(order);
          attachments.push({
            filename: `Invoice_${order.id || "order"}.pdf`,
            content: pdfBuffer,
            contentType: "application/pdf",
          });
        } catch (pdfErr: any) {
          console.error("PDF generation failed, sending mail without PDF:", pdfErr);
        }
      }

      await transporter.sendMail({
        from: `"Buy A to Z Support" <${emailUser}>`,
        to,
        subject,
        html,
        attachments,
      });

      res.json({ success: true });
    } catch (error: any) {
      console.warn("\n========================================================");
      console.warn("⚠️  [Gmail SMTP / Connection Failure] ⚠️");
      console.warn("SMTP email notification failed or timed out: ", error?.message || error);
      console.warn("Falling back smoothly to simulation mode so user is not blocked.");
      console.warn("========================================================\n");

      console.log(`[SIMULATED EMAIL SENT] To: ${to}, Subject: ${subject}`);
      res.json({ 
        success: true, 
        simulated: true, 
        error: formatSmtpError(error) 
      });
    }
  });

  app.post("/api/send-otp", async (req, res) => {
    const { to, code, fullName } = req.body;
    const isEmail = to.includes('@');

    try {
      if (isEmail) {
        // 1. Try sending via Email (Nodemailer/SMTP)
        try {
          const emailUser = process.env.EMAIL_USER?.trim();
          const emailPass = process.env.EMAIL_PASS?.replace(/\s/g, "");

          if (!emailUser || !emailPass) {
            throw new Error("SMTP configuration missing (EMAIL_USER/PASS)");
          }

          const transporter = nodemailer.createTransport({
            host: "smtp.gmail.com",
            port: 465,
            secure: true,
            auth: { user: emailUser, pass: emailPass },
            pool: true,
            maxConnections: 5,
            maxMessages: 100,
            connectionTimeout: 3000, // 3s connection timeout
            greetingTimeout: 3000,   // 3s greeting timeout
            socketTimeout: 5000,     // 5s socket timeout
          });

          await transporter.sendMail({
            from: `"Buy A to Z Support" <${emailUser}>`,
            to,
            subject: `${code} - ভেরিফিকেশন কোড (Buy A to Z)`,
            html: `
              <div style="font-family: sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
                <h2 style="color: #f85606; text-align: center;">Buy A to Z</h2>
                <p>হ্যালো ${fullName || 'User'},</p>
                <p>আপনার অ্যাকাউন্টের নিরাপত্তা নিশ্চিত করতে নিচের ৬ অক্ষরের ভেরিফিকেশন কোডটি ব্যবহার করুন:</p>
                <div style="font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #f85606; padding: 15px; background: #fff5f0; border: 1px dashed #f85606; border-radius: 5px; text-align: center; margin: 20px 0;">
                  ${code}
                </div>
                <p style="color: #666; font-size: 13px;">এই কোডটি পরবর্তী ১০ মিনিটের জন্য কার্যকর থাকবে। আপনি যদি এই অনুরোধটি না করে থাকেন, তবে সাধারণভাবেই এই ইমেইলটি এড়িয়ে যান।</p>
                <hr style="border: none; border-top: 1px solid #eee; margin: 25px 0;" />
                <p style="font-size: 11px; color: #999; text-align: center;">© 2026 Buy A to Z Ecommerce. All rights reserved.</p>
              </div>
            `,
          });
          
          return res.json({ success: true });
        } catch (mailErr: any) {
          console.warn("\n========================================================");
          console.warn("⚠️  [Gmail SMTP / Connection Failure for OTP] ⚠️");
          console.warn("SMTP email notification failed or timed out: ", mailErr?.message || mailErr);
          console.warn("Falling back smoothly to simulation mode for OTP.");
          console.warn("========================================================\n");

          console.log(`[SIMULATED OTP EMAIL SENT] To: ${to}, Code: ${code}`);
          return res.json({ 
            success: true, 
            simulated: true, 
            error: formatSmtpError(mailErr) 
          });
        }
      } else {
        // 2. Try sending via SMS (Vonage / Nexmo)
        const vonageKey = process.env.VONAGE_API_KEY;
        const vonageSecret = process.env.VONAGE_API_SECRET;
        const vonageFrom = process.env.VONAGE_FROM || "BuyAtoZ";

        // Professional formatting for SMS
        const digits = to.replace(/\D/g, '');
        let formattedTo = digits;
        
        if (digits.length === 11 && digits.startsWith('01')) {
          formattedTo = `88${digits}`;
        } else if (digits.length === 10 && digits.startsWith('1')) {
          formattedTo = `880${digits}`;
        } else if (digits.startsWith('880') && digits.length === 13) {
          formattedTo = digits;
        }

        if (vonageKey && vonageSecret) {
          console.log(`Sending Vonage SMS to: ${formattedTo}`);
          const { Vonage } = await import("@vonage/server-sdk");
          // @ts-ignore
          const vonage = new Vonage({ apiKey: vonageKey, apiSecret: vonageSecret });
          
          await vonage.sms.send({
            to: formattedTo,
            from: vonageFrom,
            text: `Buy A to Z: Your verification code is ${code}.`
          });
        } 
        // 3. Fallback to Twilio
        else if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
          console.log(`Sending Twilio SMS to: +${formattedTo}`);
          const twilio = (await import("twilio")).default;
          const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
          
          await client.messages.create({
            body: `Buy A to Z: Your verification code is ${code}.`,
            from: process.env.TWILIO_PHONE_NUMBER,
            to: `+${formattedTo}`
          });
        }
        else {
          console.warn("No SMS Gateway configured. Sending to Simulation Mode.");
          throw new Error("SMS গেটওয়ে কনফিগার করা নেই।");
        }
      }

      res.json({ success: true });
    } catch (error: any) {
      console.error("Notification failed:", error.message);
      
      const formattedErr = formatSmtpError(error);

      // If everything fails, we tell the frontend it's "Simulation Mode" 
      // so the developer can still see the code for testing.
      res.status(500).json({ 
        success: false, 
        error: formattedErr,
        isDevMissing: error.message.includes("missing") || error.message.includes("গেটওয়ে") || error.message.includes("configuration") || error.message.includes("535") || error.message.includes("EAUTH"),
        suggestedAction: "Please set API keys in Settings > Secrets for real SMS/Email."
      });
    }
  });

  // 💳 Official bKash Merchant Live Payment Gateway Configuration Check & Proxy APIs
  app.get("/api/bkash/config-status", (req, res) => {
    const isConfigured = !!(
      process.env.BKASH_APP_KEY &&
      process.env.BKASH_APP_SECRET &&
      process.env.BKASH_USERNAME &&
      process.env.BKASH_PASSWORD
    );
    res.json({
      success: true,
      configured: isConfigured,
      isLive: process.env.BKASH_IS_LIVE === "true",
      baseUrl: process.env.BKASH_IS_LIVE === "true"
        ? "https://checkout.pay.bka.sh/v1.2.0-beta"
        : "https://checkout.sandbox.bka.sh/v1.2.0-beta"
    });
  });

  // Helper function to dynamically grant bKash token on our secure backend server
  const getBkashHeaders = async () => {
    const username = (process.env.BKASH_USERNAME || "").trim();
    const password = (process.env.BKASH_PASSWORD || "").trim();
    const appKey = (process.env.BKASH_APP_KEY || "").trim();
    const appSecret = (process.env.BKASH_APP_SECRET || "").trim();
    const isLive = process.env.BKASH_IS_LIVE === "true";
    const baseUrl = isLive
      ? "https://checkout.pay.bka.sh/v1.2.0-beta"
      : "https://checkout.sandbox.bka.sh/v1.2.0-beta";

    if (!username || !password || !appKey || !appSecret) {
      throw new Error("লাইভ বিকাশ API কী (Credentials) সার্ভারে কনফিগার করা নেই! দয়া করে Settings > Secrets এ যান।");
    }

    const tokenUrl = `${baseUrl}/checkout/token/grant`;
    const response = await fetch(tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        username,
        password
      },
      body: JSON.stringify({
        app_key: appKey,
        app_secret: appSecret
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      let parseErr;
      try {
        parseErr = JSON.parse(errText);
      } catch(e) {}
      const msg = parseErr?.errorMessage || parseErr?.statusMessage || errText;
      throw new Error(`বিকাশ গেটওয়ে টোকেন গ্রান্ট ব্যর্থ হয়েছে: ${msg}`);
    }

    const data: any = await response.json();
    return {
      idToken: data.id_token,
      baseUrl,
      appKey
    };
  };

  // Create API Checkout payment session on official bKash platform
  app.post("/api/bkash/create-payment", async (req, res) => {
    const { amount, orderId, payerReference } = req.body;

    try {
      const { idToken, baseUrl, appKey } = await getBkashHeaders();

      // Find external server domain or fallback dynamically
      const protocol = req.secure || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
      const host = req.get("host");
      const callbackURL = `${protocol}://${host}/api/bkash/callback`;

      const createUrl = `${baseUrl}/checkout/payment/create`;
      const response = await fetch(createUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${idToken}`,
          "X-APP-Key": appKey
        },
        body: JSON.stringify({
          mode: "0011",
          payerReference: payerReference || "01726058933",
          callbackURL,
          amount: String(amount),
          currency: "BDT",
          intent: "sale",
          merchantInvoiceNumber: orderId || `INV-${Date.now()}`
        })
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`বিকাশ পেমেন্ট সেশন ক্রিয়েট ব্যর্থ: ${errText}`);
      }

      const data: any = await response.json();
      
      if (data.statusCode && data.statusCode !== "0000") {
        throw new Error(data.statusMessage || `Error code ${data.statusCode}`);
      }

      res.json({ success: true, paymentID: data.paymentID, bkashURL: data.bkashURL });
    } catch (e: any) {
      console.error("bKash payment creation error:", e);
      res.status(500).json({ success: false, error: e.message });
    }
  });

  // Callback handler to capture official bKash redirect confirmation or cancellations
  app.get("/api/bkash/callback", async (req, res) => {
    const { paymentID, status } = req.query;

    if (status === "cancel" || status === "failure") {
      return res.redirect(`/?bkash_status=${status}`);
    }

    try {
      const { idToken, baseUrl, appKey } = await getBkashHeaders();

      // Execute transaction instantly on official servers to successfully capture the cash
      const executeUrl = `${baseUrl}/checkout/payment/execute`;
      const response = await fetch(executeUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${idToken}`,
          "X-APP-Key": appKey
        },
        body: JSON.stringify({ paymentID })
      });

      const data: any = await response.json();

      if (data.statusCode && data.statusCode !== "0000") {
        throw new Error(data.statusMessage || `Error code ${data.statusCode}`);
      }

      // If execution was successful
      if (data.transactionStatus === "Completed") {
        return res.redirect(`/?bkash_status=success&paymentID=${paymentID}&trxID=${data.trxID}&amount=${data.amount}&invoice=${data.merchantInvoiceNumber}`);
      } else {
        throw new Error("পেমেন্ট সফলভাবে সম্পাদিত হয়নি। স্ট্যাটাস ইনকমপ্লিট।");
      }
    } catch (e: any) {
      console.error("bKash executing callback token error:", e);
      return res.redirect(`/?bkash_status=error&message=${encodeURIComponent(e.message)}`);
    }
  });

  // Query transaction status safely from security context
  app.post("/api/bkash/query-payment", async (req, res) => {
    const { paymentID } = req.body;
    try {
      const { idToken, baseUrl, appKey } = await getBkashHeaders();
      const response = await fetch(`${baseUrl}/checkout/payment/query`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${idToken}`,
          "X-APP-Key": appKey
        },
        body: JSON.stringify({ paymentID })
      });
      const data = await response.json();
      res.json({ success: true, data });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
